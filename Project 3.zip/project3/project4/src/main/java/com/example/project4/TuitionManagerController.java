package com.example.project4;

import javafx.event.ActionEvent;
import javafx.event.Event;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

import java.io.File;
import java.io.FileNotFoundException;
import java.net.URL;
import java.text.DecimalFormat;
import java.time.LocalDate;
import java.time.chrono.Chronology;
import java.util.ResourceBundle;
import java.util.Scanner;
import java.util.StringTokenizer;

/**
 * This class contains event handlers to run the GUI design functionalities in TuitionManagerView
 * @author Ashika Nadella, Christopher Blanchard
 */
public class TuitionManagerController{
    @FXML
    private TextField rosterFirstName;
    @FXML
    private TextField enrollFirstName;
    @FXML
    private TextField scholarFirstName;
    @FXML
    private TextField rosterLastName;
    @FXML
    private TextField enrollLastName;
    @FXML
    private TextField scholarLastName;
    @FXML
    private DatePicker rosterDob;
    @FXML
    private DatePicker enrollDob;
    @FXML
    private DatePicker scholarDob;
    @FXML
    private TextField rosterCredits;
    @FXML
    private TextField enrollCredits;
    @FXML
    private TextField scholarAmount;
    @FXML
    private TextArea rosterOutput;
    @FXML
    private TextArea enrollOutput;
    @FXML
    private TextArea scholarOutput;
    @FXML
    private TextArea printOutput;
    @FXML
    private Button add;
    @FXML
    private Button remove;
    @FXML
    private Button changeMajor;
    @FXML
    private Button loadFromFile;
    @FXML
    private Button enroll;
    @FXML
    private Button drop;
    @FXML
    private Button updateScholarship;
    @FXML
    private Button printProfile;
    @FXML
    private Button printSchool;
    @FXML
    private Button printStanding;
    @FXML
    private Button RBS;
    @FXML
    private Button SAS;
    @FXML
    private Button SC;
    @FXML
    private Button SOE;
    @FXML
    private Button enrolledStudents;
    @FXML
    private Button tuitionDue;
    @FXML
    private Button semesterEnd;
    @FXML
    private RadioButton radioBAIT;
    @FXML
    private RadioButton radioCS;
    @FXML
    private RadioButton radioECE;
    @FXML
    private RadioButton radioITI;
    @FXML
    private RadioButton radioMATH;
    @FXML
    private RadioButton radioResident;
    @FXML
    private RadioButton radioNonResident;
    @FXML
    private RadioButton radioDefaultNonResident;
    @FXML
    private RadioButton radioTriState;
    @FXML
    private RadioButton radioInternational;
    @FXML
    private RadioButton radioNY;
    @FXML
    private RadioButton radioCT;
    @FXML
    private CheckBox checkStudyAbroad;
    @FXML
    private RadioButton scholarAddButton;
    @FXML
    private RadioButton scholarSetButton;
    @FXML
    private Tab rosterTab;
    @FXML
    private Tab enrollTab;
    @FXML
    private Tab scholarTab;
    @FXML
    private Tab printTab;
    @FXML
    private String persistentFirstName = null;
    @FXML
    private String persistentLastName = null;
    @FXML
    private LocalDate persistentDob = null;
    @FXML
    private FileChooser fileChooser = new FileChooser();
    /**
     * Gets and sets roster first name
     */
    @FXML
    void rosterSetPersistentFirstName(){
        persistentFirstName = rosterFirstName.getText();
    }
    /**
     * Gets and sets enroll first name
     */
    @FXML
    void enrollSetPersistentFirstName(){
        persistentFirstName = enrollFirstName.getText();
    }
    /**
     * Gets and sets scholar first name
     */
    @FXML
    void scholarSetPersistentFirstName(){
        persistentFirstName = scholarFirstName.getText();
    }
    /**
     * Gets and sets roster last name
     */
    @FXML
    void rosterSetPersistentLastName(){
        persistentLastName = rosterLastName.getText();
    }
    /**
     * Gets and sets enroll last name
     */
    @FXML
    void enrollSetPersistentLastName(){
        persistentLastName = enrollLastName.getText();
    }

    /**
     * Gets and sets scholar last name
     */
    @FXML
    void scholarSetPersistentLastName(){
        persistentLastName = scholarLastName.getText();
    }

    /**
     * Gets and sets roster date of birth
     */
    @FXML
    void rosterSetPersistentDob(){
        if(rosterDob.getValue() == null){
            persistentDob = null;
            return;
        }
        persistentDob = rosterDob.getValue();
    }
    /**
     * Gets and sets enroll date of birth
     */
    @FXML
    void enrollSetPersistentDob(){
        if(enrollDob.getValue() == null){
            persistentDob = null;
            return;
        }
        persistentDob = enrollDob.getValue();
    }
    /**
     * Gets and sets scholar date of birth
     */
    @FXML
    void scholarSetPersistentDob(){
        if(scholarDob.getValue() == null){
            persistentDob = null;
             return;
        }
        persistentDob = scholarDob.getValue();
    }
    /**
     * Behavior when selection be changed.
     * @param event Button press Event.
     */
    @FXML
    void OnChanged(Event event){
        if(rosterTab != null) {
            if(rosterTab.isSelected()) {
                rosterFirstName.setText(persistentFirstName);
                rosterLastName.setText(persistentLastName);
                rosterDob.setValue(persistentDob);
            }
        }
        if(enrollTab != null) {
            if(enrollTab.isSelected()) {
                enrollFirstName.setText(persistentFirstName);
                enrollLastName.setText(persistentLastName);
                enrollDob.setValue(persistentDob);
            }
        }
        if(scholarTab != null) {
            if(scholarTab.isSelected()) {
                scholarFirstName.setText(persistentFirstName);
                scholarLastName.setText(persistentLastName);
                scholarDob.setValue(persistentDob);
            }
        }
        if(printTab != null) {
            if(printTab.isSelected()) {
            }
        }
    }
    /**
     * Behavior when button be pressed.
     * @param event Button press Event.
     */
    @FXML
    void OnResidentPressed(ActionEvent event){
        radioDefaultNonResident.setDisable(true);
        radioTriState.setDisable(true);
        radioInternational.setDisable(true);
        radioNY.setDisable(true);
        radioCT.setDisable(true);
        checkStudyAbroad.setDisable(true);

        radioDefaultNonResident.setSelected(true);
        radioTriState.setSelected(false);
        radioInternational.setSelected(false);
        radioNY.setSelected(true);
        radioCT.setSelected(false);
        checkStudyAbroad.setSelected(false);
    }
    /**
     * Behavior when button be pressed.
     * @param event Button press Event.
     */
    @FXML
    void OnNonResidentPressed(ActionEvent event){
        radioDefaultNonResident.setDisable(false);
        radioTriState.setDisable(false);
        radioInternational.setDisable(false);
        radioNY.setDisable(true);
        radioCT.setDisable(true);
        checkStudyAbroad.setDisable(true);

        radioDefaultNonResident.setSelected(true);
        radioTriState.setSelected(false);
        radioInternational.setSelected(false);
        radioNY.setSelected(true);
        radioCT.setSelected(false);
        checkStudyAbroad.setSelected(false);
    }
    /**
     * Behavior when button be pressed.
     * @param event Button press Event.
     */
    @FXML
    void OnDefaultNonResidentPressed(ActionEvent event){
        radioNY.setDisable(true);
        radioCT.setDisable(true);
        checkStudyAbroad.setDisable(true);

        radioNY.setSelected(true);
        radioCT.setSelected(false);
        checkStudyAbroad.setSelected(false);
    }
    /**
     * Behavior when button be pressed.
     * @param event Button press Event.
     */
    @FXML
    void OnTriStatePressed(ActionEvent event){
        radioNY.setDisable(false);
        radioCT.setDisable(false);
        checkStudyAbroad.setDisable(true);

        radioNY.setSelected(true);
        radioCT.setSelected(false);
        checkStudyAbroad.setSelected(false);
    }
    /**
     * Behavior when button be pressed.
     * @param event Button press Event.
     */
    @FXML
    void OnInternationalPressed(ActionEvent event){
        radioNY.setDisable(true);
        radioCT.setDisable(true);
        checkStudyAbroad.setDisable(false);

        radioNY.setSelected(true);
        radioCT.setSelected(false);
        checkStudyAbroad.setSelected(false);
    }
    @FXML
    Roster obj = new Roster();
    @FXML
    Enrollment enrollObject = new Enrollment();
    /**
     * Adds a Student if they pass all the exceptions.
     * @param event the event that is performed when Add button is clicked
     */
    @FXML
    void OnAddPressed(ActionEvent event){
        if(RosterIsMissingData()) {
            rosterOutput.appendText("Missing data.\n");
            return;
        }
        Major major = RosterSetMajor();
        String credits = rosterCredits.getText();
        String dob = rosterDob.getValue().getMonthValue() + "/" + rosterDob.getValue().getDayOfMonth() + "/" + rosterDob.getValue().getYear();
        Profile profileToAdd = new Profile(rosterFirstName.getText(), rosterLastName.getText(), dob);
        if(profileToAdd.getDob().birthDateAge() < 16) {
            rosterOutput.appendText("Student does not meet age requirement (16 or older).\n");
            return;
        }
        if(NotAnInteger(credits)){
            rosterOutput.appendText("Credits completed is not an integer.\n");
            return;
        }
        int creditsCompleted = Integer.parseInt(credits);
        if(creditsCompleted < 0){
            rosterOutput.appendText("Credits completed is less than 0.\n");
            return;
        }
        if (obj.findByProfile(profileToAdd) != -1) {
            rosterOutput.appendText("Cannot add student: " + profileToAdd.getFname() + " " + profileToAdd.getLname() + " " + profileToAdd.getDob() + " is already in the roster.\n");
            return;
        }
        Student toAdd = null;
        if(radioResident.isSelected()) toAdd = new Resident(profileToAdd, major, creditsCompleted);
        if(radioNonResident.isSelected() && radioDefaultNonResident.isSelected()) toAdd = new NonResident(profileToAdd, major, creditsCompleted);
        if(radioNonResident.isSelected() && radioTriState.isSelected() && radioNY.isSelected()) toAdd = new TriState(profileToAdd,major,creditsCompleted,"NY");
        if(radioNonResident.isSelected() && radioTriState.isSelected() && radioCT.isSelected()) toAdd = new TriState(profileToAdd,major,creditsCompleted,"CT");
        if(radioNonResident.isSelected() && radioInternational.isSelected() && checkStudyAbroad.isSelected()) toAdd = new International(profileToAdd,major,creditsCompleted,true);
        if(radioNonResident.isSelected() && radioInternational.isSelected() && !checkStudyAbroad.isSelected()) toAdd = new International(profileToAdd,major,creditsCompleted,false);
        if(toAdd == null) return;
        obj.add(toAdd);
        rosterOutput.appendText(toAdd + " was successfully added to the roster.\n");
    }

    /**
     * Tries to remove a student from the Roster.
     * @param event the event that is performed when remove button is clicked
     */
    @FXML
    void OnRemovePressed(ActionEvent event){
        if(RosterIsMissingData()) {
            rosterOutput.appendText("Missing data.\n");
            return;
        }
        String dob = rosterDob.getValue().getMonthValue() + "/" + rosterDob.getValue().getDayOfMonth() + "/" + rosterDob.getValue().getYear();
        Profile profileToRemove = new Profile(rosterFirstName.getText(), rosterLastName.getText(), dob);
        if(enrollObject.findByProfile(profileToRemove) != -1){
            rosterOutput.appendText("Student is currently enrolled. They cannot be removed from the roster unless their enrollment is dropped.\n");
            return;
        }
        if(obj.findByProfile(profileToRemove) == -1) {
            rosterOutput.appendText("Cannot remove student: " + profileToRemove.getFname() + " " + profileToRemove.getLname() + " " + profileToRemove.getDob() + " is not in the roster.\n");
            return;
        }
        obj.remove(obj.getRoster()[obj.findByProfile(profileToRemove)]);
        rosterOutput.appendText(profileToRemove.getFname() + " " + profileToRemove.getLname() + " " + profileToRemove.getDob() + " was successfully removed from the roster.\n");
    }

    /**
     * Finds a Student in the given Roster, and changes their Major to the given Major.
     * @param event the event that is performed when change major button is clicked
     */
    @FXML
    void OnChangeMajorPressed(ActionEvent event){
        if(RosterIsMissingData()) {
            rosterOutput.appendText("Missing data.\n");
            return;
        }
        Major newMajor = RosterSetMajor();
        String dob = rosterDob.getValue().getMonthValue() + "/" + rosterDob.getValue().getDayOfMonth() + "/" + rosterDob.getValue().getYear();
        Profile profileToChange = new Profile(rosterFirstName.getText(), rosterLastName.getText(), dob);
        if(obj.findByProfile(profileToChange) == -1) {
            rosterOutput.appendText("Cannot change major: " + profileToChange.getFname() + " " + profileToChange.getLname() + " " + profileToChange.getDob() + " is not in the roster.\n");
            return;
        }
        if(obj.getRoster()[obj.findByProfile(profileToChange)].getMajor() == newMajor){
            rosterOutput.appendText(profileToChange.getFname() + " " + profileToChange.getLname() + " " + profileToChange.getDob() + " already has the selected major.\n");
            return;
        }
        obj.changeMajor(obj.findByProfile(profileToChange),newMajor);
        rosterOutput.appendText(profileToChange.getFname() + " " + profileToChange.getLname() + " " + profileToChange.getDob() + " major was successfully changed to " + newMajor + "\n");
    }
    /**
     * Returns the major for the appropriate school selected.
     * @return Major according to the school that is selected
     */
    private Major RosterSetMajor(){
        if(radioBAIT.isSelected()) return Major.BAIT;
        if(radioCS.isSelected()) return Major.CS;
        if(radioECE.isSelected()) return Major.EE;
        if(radioITI.isSelected()) return Major.ITI;
        if(radioMATH.isSelected()) return Major.MATH;
        return Major.BAIT;
    }

    /**
     * Checks if some roster data fields are empty or not.
     * @return boolean: true if the data field is empty
     */
    private boolean RosterIsMissingData(){
        if (rosterDob.getValue() == null) return true;
        if (rosterFirstName.getText().isEmpty()) return true;
        if (rosterLastName.getText().isEmpty()) return true;
        if (rosterCredits.getText().isEmpty()) return true;
        return false;
    }

    /**
     * Checks if some scholarship data fields are empty or not.
     * @return boolean: true if the data field is empty
     */
    private boolean ScholarIsMissingData(){
        if (scholarDob.getValue() == null) return true;
        if (scholarFirstName.getText().isEmpty()) return true;
        if (scholarLastName.getText().isEmpty()) return true;
        if (scholarAmount.getText().isEmpty()) return true;
        return false;
    }

    /**
     * Checks if string is an integer or not.
     * @param toParse the string that is being parsed
     * @return boolean: false if the string is integer
     */
    private boolean NotAnInteger(String toParse){
        try {
            Integer.parseInt(toParse);
        } catch (Exception e) {
            return true;
        }
        return false;
    }
    /**
     * Enrolls a Student if they pass all the exceptions.
     * @param event  the event that is performed when Enroll button is clicked
     */
    @FXML
    void OnEnrollPressed(ActionEvent event) {
        if (enrollDob.getValue()== null){
            enrollOutput.appendText("Missing data.\n");
            return;
        }
        String fname = enrollFirstName.getText();
        String lname = enrollLastName.getText();
        String dob = enrollDob.getValue().getMonthValue() + "/" + enrollDob.getValue().getDayOfMonth() + "/" +
                enrollDob.getValue().getYear();
        String credits = enrollCredits.getText();
        if (fname.isEmpty()|| lname.isEmpty() || credits.isEmpty()) {
            enrollOutput.appendText("Missing data.\n");
            return;
        }
        Profile stu = new Profile(fname, lname, dob);
        int creditsEnrolled = 0;
        try {
            creditsEnrolled = Integer.parseInt(credits);
        } catch (Exception e) {
            enrollOutput.appendText("Credits enrolled is not an integer.\n");
            return;
        }
        if (obj.findByProfile(stu) == -1) {
            enrollOutput.appendText("Cannot enroll: " + fname + " " + lname + " " + dob + " is not in the roster.\n");
            return;
        }
        if (!obj.getRoster()[obj.findByProfile(stu)].isValid(creditsEnrolled)) {
            enrollOutput.appendText("(" + obj.getRoster()[obj.findByProfile(stu)].studentTypeToString()
                    + ") " + creditsEnrolled + " : invalid credit hours.\n");
            return;
        }
        EnrollStudent student = new EnrollStudent(fname, lname, dob, creditsEnrolled);
        if(enrollObject.contains(student)){
            enrollOutput.appendText(fname + " " + lname + " " + dob + " is already enrolled.\n");
            return;
        }
        enrollObject.add(student);
        enrollOutput.appendText(fname + " " + lname + " " + dob + " enrolled " + creditsEnrolled + " credits.\n");
    }

    /**
     * Drops a Student from the enrollment.
     * @param event  the event that is performed when Drop button is clicked
     */
    @FXML
    void OnDropPressed(ActionEvent event) {
        if (enrollDob.getValue()== null){
            enrollOutput.appendText("Missing data.\n");
            return;
        }
        String fname = enrollFirstName.getText();
        String lname = enrollLastName.getText();
        String dob = enrollDob.getValue().getMonthValue() + "/" + enrollDob.getValue().getDayOfMonth() + "/" +
                enrollDob.getValue().getYear();
        if (fname.isBlank() || lname.isBlank()) {
            enrollOutput.appendText("Missing data.\n");
            return;
        }
        EnrollStudent student = new EnrollStudent(fname, lname, dob, 0);
        if(!enrollObject.contains(student)){
            enrollOutput.appendText(fname + " " + lname + " " + dob + " is not enrolled.\n");
            return;
        }
        enrollObject.remove(student);
        enrollOutput.appendText(fname + " " + lname + " " + dob + " dropped.\n");
    }
    /**
     * Updates a student scholarship.
     * @param event  the event that is performed when scholarship button is clicked
     */
    @FXML
    void OnScholarPressed(ActionEvent event) {
        if(ScholarIsMissingData()) {
            scholarOutput.appendText("Missing data.\n");
            return;
        }
        String dob = scholarDob.getValue().getMonthValue() + "/" + scholarDob.getValue().getDayOfMonth() + "/" + scholarDob.getValue().getYear();
        Profile profileToSearch = new Profile(scholarFirstName.getText(), scholarLastName.getText(), dob);
        int studentIndex = obj.findByProfile(profileToSearch);
        if(studentIndex == -1) {
            scholarOutput.appendText(profileToSearch.getFname() + " " + profileToSearch.getLname() + " " + profileToSearch.getDob() + " is not in the roster.\n");
            return;
        }
        try{
            Integer.parseInt(scholarAmount.getText());
        }catch(Exception e) {
            scholarOutput.appendText("Amount is not an integer.\n");
            return;
        }
        int award = Integer.parseInt(scholarAmount.getText());
        if (obj.getRoster()[studentIndex].getClass().getSimpleName().compareTo("Resident") != 0) {
            scholarOutput.appendText(profileToSearch.getFname() + " " + profileToSearch.getLname() + " " + profileToSearch.getDob() + " (" + obj.getRoster()[studentIndex].studentTypeToString() + ") is not eligible for the scholarship.\n");
            return;
        }
        if(scholarAddButton.isSelected()){
            AddScholarship(profileToSearch, studentIndex, award);
        }
        if(scholarSetButton.isSelected()){
            SetScholarship(profileToSearch, studentIndex, award);
        }
    }

    /**
     * Adds a scholarship amount to a student. Scholarship amount must fit the bounds.
     * @param profile profile of the student to add the scholarship to
     * @param index index of the student to add the scholarship to
     * @param award amount of the scholarship to add
     */
    @FXML
    void AddScholarship(Profile profile, int index, int award){
        if(award < 1){
            scholarOutput.appendText("Must add an amount.\n");
            return;
        }
        if(award > ((Resident)obj.getRoster()[index]).MAX_SCHOLARSHIP_ADDED){
            scholarOutput.appendText("Maximum scholarship award is: " + ((Resident)obj.getRoster()[index]).MAX_SCHOLARSHIP_ADDED + "\n");
            return;
        }
        ((Resident)obj.getRoster()[index]).awardScholarship(award);
        scholarOutput.appendText(profile.getFname() + " " + profile.getLname() + " " + profile.getDob() +
                ": added " + award + " to scholarship. Total: " + ((Resident)obj.getRoster()[index]).getScholarship() + "\n");
    }
    /**
     * Sets a student's scholarship amount.
     * @param profile profile of the student to add the scholarship to
     * @param index index of the student to add the scholarship to
     * @param award amount of the scholarship to add
     */
    @FXML
    void SetScholarship(Profile profile, int index, int award){
        if(award < 0) {
            scholarOutput.appendText(award + ": invalid amount.\n");
            return;
        }
        ((Resident)obj.getRoster()[index]).setScholarship(award);
        scholarOutput.appendText(profile.getFname() + " " + profile.getLname() + " " + profile.getDob() +
                ": scholarship amount updated. Total: " + ((Resident)obj.getRoster()[index]).getScholarship() + "\n");
    }
    /**
     * Sorts students in the roster by their last names, first names, and dobs.
     * @param event  the event that is performed when print by profile button is clicked
     */
    @FXML
    void OnPrintByProfilePressed(ActionEvent event) {
        if (obj.studentsInRoster() == 0) {
            printOutput.appendText("Student roster is empty!\n");
            return;
        }
        printOutput.appendText("* Student roster sorted by last name, first name, DOB **\n");
        obj.print();
        for (int i = 0; i < obj.getSize(); i++) {
            if (obj.getRoster()[i] == null) {
                break;
            }
            printOutput.appendText(obj.getRoster()[i].getProfile() + " (" + obj.getRoster()[i].getMajor().getCode() + " "
                    + obj.getRoster()[i].getMajor() + " " + obj.getRoster()[i].getMajor().getSchool() + ") credits completed: "
                    + obj.getRoster()[i].getCreditsCompleted() + " (" + obj.getRoster()[i].getStanding(obj.getRoster()[i])
                    + ") " + obj.getRoster()[i].studentTypeToStringGradFormat() + ".\n");
        }
        printOutput.appendText("* end of roster **\n");
    }

    /**
     * Sorts students in the roster by their schools, and majors.
     * @param event  the event that is performed when print by school/major button is clicked
     */
    @FXML
    void OnPrintBySchoolPressed(ActionEvent event) {

        if (obj.studentsInRoster() == 0) {
            printOutput.appendText("Student roster is empty!\n");
            return;
        }
        printOutput.appendText("* Student roster sorted by school, major **\n");
        obj.printBySchoolMajor();
        for (int i = 0; i < obj.getSize(); i++) {
            if (obj.getRoster()[i] == null) {
                break;
            }
            printOutput.appendText(obj.getRoster()[i].getProfile() + " (" + obj.getRoster()[i].getMajor().getCode() + " "
                    + obj.getRoster()[i].getMajor() + " " + obj.getRoster()[i].getMajor().getSchool() + ") credits completed: "
                    + obj.getRoster()[i].getCreditsCompleted() + " (" + obj.getRoster()[i].getStanding(obj.getRoster()[i])
                    + ") " + obj.getRoster()[i].studentTypeToStringGradFormat()+ ".\n");
        }
        printOutput.appendText("* end of roster **\n");
    }

    /**
     * Sorts students in the roster by their standing.
     * @param event  the event that is performed when print by standing button is clicked
     */
    @FXML
    void OnPrintByStandingPressed(ActionEvent event) {

        if (obj.studentsInRoster() == 0) {
            printOutput.appendText("Student roster is empty!\n");
            return;
        }
        printOutput.appendText("* Student roster sorted by standing **\n");
        obj.printByStanding();
        for (int i = 0; i < obj.getSize(); i++) {
            if (obj.getRoster()[i] == null) {
                break;
            }
            printOutput.appendText(obj.getRoster()[i].getProfile() + " (" + obj.getRoster()[i].getMajor().getCode() + " "
                    + obj.getRoster()[i].getMajor() + " " + obj.getRoster()[i].getMajor().getSchool() + ") credits completed: "
                    + obj.getRoster()[i].getCreditsCompleted() + " (" + obj.getRoster()[i].getStanding(obj.getRoster()[i])
                    + ") " + obj.getRoster()[i].studentTypeToStringGradFormat()+".\n");
        }
        printOutput.appendText("* end of roster **\n");
    }

    /**
     * Lists students in the RBS sorted by their profiles.
     * @param event  the event that is performed when print RBS button is clicked
     */
    @FXML
    void OnPrintRBSPressed(ActionEvent event) {
        String school = "RBS";
        if (obj.studentsInRoster() == 0) {
            printOutput.appendText("Student roster is empty!\n");
            return;
        }
        boolean requestedSchoolInSystem = false;
        for (int i = 0; i < Major.values().length - 1; i++) {
            if (school.equalsIgnoreCase(Major.values()[i].getSchool())) {
                requestedSchoolInSystem = true;
                break;
            }
        }
        if (!requestedSchoolInSystem) {
            printOutput.appendText("School doesn't exist: " + school + ".\n");
            return;
        } else {
            printOutput.appendText("* Students in " + school + " *\n");
            obj.printThisSchoolOnly(school);
            for (int i = 0; i < obj.getSize(); i++) {
                if (obj.getRoster()[i] == null) {
                    break;
                }
                if (obj.getRoster()[i].getMajor().getSchool().equalsIgnoreCase(school)) {
                    printOutput.appendText(obj.getRoster()[i].getProfile() + " (" + obj.getRoster()[i].getMajor().getCode() + " "
                            + obj.getRoster()[i].getMajor() + " " + obj.getRoster()[i].getMajor().getSchool() + ") credits completed: "
                            + obj.getRoster()[i].getCreditsCompleted() + " (" + obj.getRoster()[i].getStanding(obj.getRoster()[i])
                            + ") " + obj.getRoster()[i].studentTypeToStringGradFormat() + ".\n");
                }
            }
            printOutput.appendText("* end of list **\n");
        }

    }

    /**
     * Lists students in the SAS sorted by their profiles.
     * @param event  the event that is performed when print SAS button is clicked
     */
    @FXML
    void OnPrintSASPressed(ActionEvent event) {
        String school = "SAS";
        if (obj.studentsInRoster() == 0) {
            printOutput.appendText("Student roster is empty!\n");
            return;
        }
        boolean requestedSchoolInSystem = false;
        for (int i = 0; i < Major.values().length - 1; i++) {
            if (school.equalsIgnoreCase(Major.values()[i].getSchool())) {
                requestedSchoolInSystem = true;
                break;
            }
        }
        if (!requestedSchoolInSystem) {
            printOutput.appendText("School doesn't exist: " + school + ".\n");
            return;
        } else {
            printOutput.appendText("* Students in " + school + " *\n");
            obj.printThisSchoolOnly(school);
            for (int i = 0; i < obj.getSize(); i++) {
                if (obj.getRoster()[i] == null) {
                    break;
                }
                if (obj.getRoster()[i].getMajor().getSchool().equalsIgnoreCase(school)) {
                    printOutput.appendText(obj.getRoster()[i].getProfile() + " (" + obj.getRoster()[i].getMajor().getCode() + " "
                            + obj.getRoster()[i].getMajor() + " " + obj.getRoster()[i].getMajor().getSchool() + ") credits completed: "
                            + obj.getRoster()[i].getCreditsCompleted() + " (" + obj.getRoster()[i].getStanding(obj.getRoster()[i])
                            + ") " + obj.getRoster()[i].studentTypeToStringGradFormat() + ".\n");
                }
            }
            printOutput.appendText("* end of list **\n");
        }
    }

    /**
     * Lists students in the SC sorted by their profiles.
     * @param event  the event that is performed when print SC&I button is clicked
     */
    @FXML
    void OnPrintSCIPressed(ActionEvent event) {
        String school = "SC&I";
        if (obj.studentsInRoster() == 0) {
            printOutput.appendText("Student roster is empty!\n");
            return;
        }
        boolean requestedSchoolInSystem = false;
        for (int i = 0; i < Major.values().length - 1; i++) {
            if (school.equalsIgnoreCase(Major.values()[i].getSchool())) {
                requestedSchoolInSystem = true;
                break;
            }
        }
        if (!requestedSchoolInSystem) {
            printOutput.appendText("School doesn't exist: " + school +".\n");
            return;
        } else {
            printOutput.appendText("* Students in " + school + " *\n");
            obj.printThisSchoolOnly(school);
            for (int i = 0; i < obj.getSize(); i++) {
                if (obj.getRoster()[i] == null) {
                    break;
                }
                if (obj.getRoster()[i].getMajor().getSchool().equalsIgnoreCase(school)) {
                    printOutput.appendText(obj.getRoster()[i].getProfile() + " (" + obj.getRoster()[i].getMajor().getCode() + " "
                            + obj.getRoster()[i].getMajor() + " " + obj.getRoster()[i].getMajor().getSchool() + ") credits completed: "
                            + obj.getRoster()[i].getCreditsCompleted() + " (" + obj.getRoster()[i].getStanding(obj.getRoster()[i])
                            + ") " + obj.getRoster()[i].studentTypeToStringGradFormat() +".\n");
                }
            }
            printOutput.appendText("* end of list **\n");
        }

    }

    /**
     * Lists students in the SOE sorted by their profiles.
     * @param event  the event that is performed when print SOE button is clicked
     */
    @FXML
    void OnPrintSOEPressed(ActionEvent event) {
        String school = "SOE";
        if (obj.studentsInRoster() == 0) {
            printOutput.appendText("Student roster is empty!\n");
            return;
        }
        boolean requestedSchoolInSystem = false;
        for (int i = 0; i < Major.values().length - 1; i++) {
            if (school.equalsIgnoreCase(Major.values()[i].getSchool())) {
                requestedSchoolInSystem = true;
                break;
            }
        }
        if (!requestedSchoolInSystem) {
            printOutput.appendText("School doesn't exist: " + school+ ".\n");
            return;
        } else {
            printOutput.appendText("* Students in " + school + " *\n");
            obj.printThisSchoolOnly(school);
            for (int i = 0; i < obj.getSize(); i++) {
                if (obj.getRoster()[i] == null) {
                    break;
                }
                if (obj.getRoster()[i].getMajor().getSchool().equalsIgnoreCase(school)) {
                    printOutput.appendText(obj.getRoster()[i].getProfile() + " (" + obj.getRoster()[i].getMajor().getCode() + " "
                            + obj.getRoster()[i].getMajor() + " " + obj.getRoster()[i].getMajor().getSchool() + ") credits completed: "
                            + obj.getRoster()[i].getCreditsCompleted() + " (" + obj.getRoster()[i].getStanding(obj.getRoster()[i])
                            + ") " + obj.getRoster()[i].studentTypeToStringGradFormat()+ ".\n");
                }
            }
            printOutput.appendText("* end of list **\n");
        }
    }

    /**
     * Print enrolled students in the order they are enrolled.
     * @param event  the event that is performed when print enrolled students button is clicked
     */
    @FXML
     void OnPrintEnrolledStudentsPressed(ActionEvent event) {
        if (enrollObject.studentsEnrolled() == 0) {
            printOutput.appendText("Enrollment is empty!\n");
            return;
        }
        printOutput.appendText("** Enrollment **\n");
        for (int x = 0; x < enrollObject.getSize(); x++) {
            if (enrollObject.getEnrollStudents()[x] != null) {
                printOutput.appendText(enrollObject.getEnrollStudents()[x] + ".\n");
            }
        }
        printOutput.appendText("* end of enrollment *\n");
    }

    /**
     * prints the amount of tuition due for the students enrolled.
     * @param event  the event that is performed when print tuition due button is clicked
     */
    @FXML
     void OnPrintTuitionDuePressed(ActionEvent event) {
        if (obj.studentsInRoster() == 0) {
            printOutput.appendText("Student roster is empty!\n");
            return;
        }
        if(enrollObject.studentsEnrolled() == 0) {
            printOutput.appendText("** No Students enrolled! **\n");
            return;
        }
        printOutput.appendText("** Tuition due **\n");
        for(int i = 0; i < enrollObject.getSize(); i++) {
            if(enrollObject.getEnrollStudents()[i] == null) continue;
            EnrollStudent studentToPrint = enrollObject.getEnrollStudents()[i];
            DecimalFormat tuitionFormat = new DecimalFormat("$#,##0.00");
            double cost = obj.getRoster()[obj.findByProfile(studentToPrint.getProfile())].tuitionDue(studentToPrint.getCreditsEnrolled());
            printOutput.appendText(studentToPrint.getProfile().getFname() + " " + studentToPrint.getProfile().getLname()
                    + " " + studentToPrint.getProfile().getDob() + " (" + obj.getRoster()[obj.findByProfile
                    (studentToPrint.getProfile())].studentTypeToString() + ") enrolled " + studentToPrint.getCreditsEnrolled()
                    + " credits: tuition due: " + tuitionFormat.format(cost)+ ".\n");

        }
        printOutput.appendText("* end of tuition due *\n");
    }

    /**
     * Calculates the total number of credits completed by students in roster.
     * Prints students who have 120 or more credits completed.
     * @param event  the event that is performed when semester end button is clicked
     */
    @FXML
     void OnSemesterEndPressed(ActionEvent event){
        if(enrollObject.studentsEnrolled() == 0){
            printOutput.appendText("No students enrolled.\n");
            return;
        }
        printOutput.appendText("Credit completed has been updated, and Enrollment list has been reset.\n");
        printOutput.appendText("** list of students eligible for graduation **\n");
        int  creditsDone = 0;
        int creditsEnrolled = 0;
        int totalCredits = 0;
        String fname;
        String lname;
        String dob;
        for (int i = 0; i < obj.getSize(); i++) {
            if (obj.getRoster()[i] == null){
                continue; }
            creditsDone = obj.getRoster()[i].getCreditsCompleted() ;
            Profile stu = obj.getRoster()[i].getProfile();
            fname = stu.getFname();
            lname = stu.getLname();
            dob = stu.getDob().toString();
            EnrollStudent s = new EnrollStudent(fname, lname, dob, 0);
            if(enrollObject.contains(s)){
                int index = enrollObject.find(s);
                creditsEnrolled = enrollObject.getEnrollStudents()[index].getCreditsEnrolled();
                totalCredits = creditsDone + creditsEnrolled;
                obj.getRoster()[i].setCreditsCompleted(totalCredits);
            } else{
                totalCredits = creditsDone;
                obj.getRoster()[i].setCreditsCompleted(totalCredits);
            }
            if (totalCredits>= 120 ){
                printOutput.appendText(obj.getRoster()[i].getProfile() + " (" + obj.getRoster()[i].getMajor().getCode() + " "
                        + obj.getRoster()[i].getMajor() + " " + obj.getRoster()[i].getMajor().getSchool() + ") credits completed: "
                        + obj.getRoster()[i].getCreditsCompleted() + " (" + obj.getRoster()[i].getStanding(obj.getRoster()[i])
                        + ") " + obj.getRoster()[i].studentTypeToStringGradFormat() +".\n");
            }
        }
        printOutput.appendText("* end of list*\n");
        enrollObject = new Enrollment(); }
    @FXML
    void OnReadFromFilePressed(ActionEvent event){
        File file = fileChooser.showOpenDialog(new Stage());
        try {
            Scanner scanner = new Scanner(file);
            while(scanner.hasNextLine()){
                StringTokenizer st = new StringTokenizer(scanner.next());
                String studentType = st.nextToken(",");
                Student studentToAdd = null;
                if	   (studentType.equals("R")&&st.countTokens()==5) {
                    studentToAdd = new Resident(st.nextToken(","),st.nextToken(","),
                            st.nextToken(","),Major.valueOf(st.nextToken(",").toUpperCase()), Integer.parseInt(st.nextToken(","))); }
                else if(studentType.equals("N")&&st.countTokens()==5){
                    studentToAdd = new NonResident(st.nextToken(","),st.nextToken(","),
                            st.nextToken(","),Major.valueOf(st.nextToken(",").toUpperCase()), Integer.parseInt(st.nextToken(","))); }
                else if(studentType.equals("T")) {
                    if(st.countTokens()==5) { rosterOutput.appendText("Missing State Code."); }
                    if(st.countTokens()==6){
                        studentToAdd = new TriState(st.nextToken(","),st.nextToken(","),
                                st.nextToken(","),Major.valueOf(st.nextToken(",").toUpperCase()),
                                Integer.parseInt(st.nextToken(",")),st.nextToken(",").toUpperCase()); }
                }
                else if(studentType.equals("I")) {
                    if(st.countTokens()==5){
                        studentToAdd = new International(st.nextToken(","),st.nextToken(","),
                                st.nextToken(","),Major.valueOf(st.nextToken(",").toUpperCase()), Integer.parseInt(st.nextToken(","))); }
                    if(st.countTokens()==6){
                        studentToAdd = new International(st.nextToken(","),st.nextToken(","),
                                st.nextToken(","),Major.valueOf(st.nextToken(",").toUpperCase()),
                                Integer.parseInt(st.nextToken(",")),Boolean.parseBoolean(st.nextToken(","))); }
                }
                if(studentToAdd != null) {
                    if (obj.findByProfile(studentToAdd.getProfile()) != -1) {
                        rosterOutput.appendText("Cannot add student: " + studentToAdd + " is already in the roster.\n");
                    }else{
                        obj.add(studentToAdd);
                        rosterOutput.appendText(studentToAdd + " was successfully added to the roster.\n"); }
                }
            }
        } catch (Exception e) { }
    }
}