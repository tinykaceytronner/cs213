package com.example.project4;

import java.util.StringTokenizer;
import java.util.Calendar;

/**
 * This class is for Date, which stores values of month, day, and year.
 * Date can be default constructed to make today's date.
 * Date can be constructed with String parameter to make date with MMDDYYYY as date.
 * Various other methods to determine whether or not date is a valid calendar date.
 * Uses String Tokenizer to delimit strings. Uses calendar to grab today's date.
 * @author Christopher Blanchard
 */
public class Date implements Comparable<Date> {
    // Instance variables.
    private int year;
    private int month;
    private int day;

    // Constant values. For purposes of determining whether or not this Date is a valid calendar date.
    public static final int QUADRENNIAL = 4;
    public static final int CENTENNIAL = 100;
    public static final int QUATERCENTENNIAL = 400;
    public static final int DAYSIN_JAN_MAR_MAY_JUL_AUG_OCT_DEC = 31;
    public static final int DAYSIN_APR_JUN_SEP_NOV = 30;
    public static final int DAYSIN_FEB_LEAP = 29;
    public static final int DAYSIN_FEB_NONLEAP = 28;

    /**
     * Default Date Constructor. Instantiates a Date that has today's month, day, and year.
     */
    public Date() {
        java.util.Date today = Calendar.getInstance().getTime();
        this.month = today.getMonth() + 1;
        this.day = today.getDate();
        this.year = today.getYear() + 1900;
    }

    /**
     * Date Constructor with parameter that determines the month, day, and year of the Date to be instantiated.
     * @param mmddyyyy MM/DD/YYYY format of the Date to be instantiated.
     */
    public Date(String mmddyyyy) {
        StringTokenizer st = new StringTokenizer(mmddyyyy);
        this.month = Integer.parseInt(st.nextToken("/"));
        this.day = Integer.parseInt(st.nextToken("/"));
        this.year = Integer.parseInt(st.nextToken("/"));
    }

    /**
     * Determines whether or not this date is greater than or equal to today's date.
     * @return True if this date is greater than or equal to today's date.
     * False if this date is less than today's date.
     */
    public boolean isTodayorFuture() {
        if (!this.isValid()) return false;
        Date today = new Date();
        return (this.compareTo(today) != -1);
    }

    /**
     * Determines whether or not this year is a leap year.
     * For purposes of determining whether or not this Date is valid.
     * @return True if this year is a leap year.
     * False if this yera is not a leap year.
     */
    private boolean isLeapYear() {
        if (!divisibleByQUADRENNIAL()) return false;
        if (!divisibleByCENTENNIAL()) return true;
        if (!divisibleByQUATERCENTENNIAL()) return false;
        return true;
    }

    /**
     * Determines whether or not this year is divisible by QUADRENNIAL.
     * For purposes of determining whether or not this Date is valid.
     * @return True if this year is divisible by QUADRENNIAL.
     * False if this year is not divisible by QUADRENNIAL.
     */
    private boolean divisibleByQUADRENNIAL() {
        return (this.year % QUADRENNIAL == 0);
    }

    /**
     * Determines whether or not this year is divisible by CENTENNIAL.
     * For purposes of determining whether or not this Date is valid.
     * @return True if this year is divisible by CENTENNIAL.
     * False if this year is not divisible by CENTENNIAL.
     */
    private boolean divisibleByCENTENNIAL() {
        return (this.year % CENTENNIAL == 0);
    }

    /**
     * Determines whether or not this year is divisible by QUATERCENTENNIAL.
     * For purposes of determining whether or not this Date is valid.
     * @return True if this year is divisible by QUATERCENTENNIAL.
     * False if this year is not divisible by QUATERCENTENNIAL.
     */
    private boolean divisibleByQUATERCENTENNIAL() {
        return (this.year % QUATERCENTENNIAL == 0);
    }

    /**
     * Determines whether or not this Date is a valid calendar date.
     * @return True if this Date is valid. False if this Date is not valid.
     */
    public boolean isValid() {
        if (this.year < 0 || this.month < 0 || this.day < 0) return false;
        switch (this.month) {
            case 1:
            case 3:
            case 5:
            case 7:
            case 8:
            case 10:
            case 12:
                // If this.day be [1, DAYSIN_JAN_MAR_MAY_JUL_AUG_OCT_DEC] this date is valid.
                if (this.day >= 1 && this.day <= DAYSIN_JAN_MAR_MAY_JUL_AUG_OCT_DEC) return true;
                // If not, this date is not valid.
                return false;
            case 4:
            case 6:
            case 9:
            case 11:
                // If this.day be [1, DAYSIN_APR_JUN_SEP_NOV] this date is valid.
                if (this.day >= 1 && this.day <= DAYSIN_APR_JUN_SEP_NOV) return true;
                // If not, this date is not valid.
                return false;
            case 2:
                if (isLeapYear()) {
                    // If this.day be [1, DAYSIN_FEB_LEAP] this date is valid.
                    if (this.day >= 1 && this.day <= DAYSIN_FEB_LEAP) return true;
                    // If not, this date is not valid.
                    return false;
                }
                // If this.day be [1, DAYSIN_FEB_NONLEAP] this date is valid.
                if (this.day >= 1 && this.day <= DAYSIN_FEB_NONLEAP) return true;
                // If not, this date is not valid.
                return false;
            default: // If this.month is NOT [1,12], this date is not valid.
                return false;
        }
    }

    /**
     * If this date be used as a birthday, return the age (in years) of entity with this birthday.
     * @return Age (in years) of entity with this date as their birthday.
     */
    public int birthDateAge() {
        if (!this.isValid()) return -1;
        Date today = new Date();
        if (this.isTodayorFuture()) return 0;
        int age = today.year - this.year;
        if (today.month > this.month) return age;
        if (today.day >= this.day) return age;
        return age - 1;
    }

    /**
     * Date toString method.
     * @return this month/day/year
     */
    public String toString() {
        return (this.month + "/" + this.day + "/" + this.year);
    }

    /**
     * Compares this date to the date passed in as a parameter.
     * @param other Date to compare with this date.
     * @return True if this Date and other Date be same. False if different.
     */
    public boolean equals(Date other) {
        return ((this.month == other.month) && (this.day == other.day) && (this.year == other.year));
    }

    /**
     * Compares this date to the date passed in as a parameter.
     * @param other Date to compare with this date.
     * @return If this date be less than other date, return -1.
     * If this date be greater than other date, return 1.
     * If the dates be equal, return 0.
     */
    @Override
    public int compareTo(Date other) {
        if (this.year < other.year) return -1;
        if (this.year > other.year) return 1;

        if (this.month < other.month) return -1;
        if (this.month > other.month) return 1;

        if (this.day < other.day) return -1;
        if (this.day > other.day) return 1;

        return 0;
    }
}
