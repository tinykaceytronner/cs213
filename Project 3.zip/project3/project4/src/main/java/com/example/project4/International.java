package com.example.project4;


/**
* This class performs isStudy Abroad, discount, and isResident functions mainly for international student
* @author Christopher Blanchard
*/
public class International extends NonResident {
	private boolean isStudyAbroad;

	  /**
	   * Getter method that gets the stsudyAbroad status of the student to access it in different classes.
	   * @return isStudyAbroad status
	   */
	public boolean getIsStudyAbroad(){
		return isStudyAbroad;
	}  
		/**
	   * Setter method that sets the stsudyAbroad status of the student to access it in different classes.
	   * @param isStudyAbroad status
	   */
	public void setIsStudyAbroad(boolean isStudyAbroad) {
		this.isStudyAbroad = isStudyAbroad;
	}
	/**
	   * constructor for International student
	   * @param fname           student's first name
	   * @param lname           student's last name
	   * @param date            student's date of birth
	   * @param major           Student's major
	   * @param creditCompleted number of credits completed by the student
	   */
    public International(String fname, String lname, String date, Major major, int creditCompleted) {
		super(fname, lname, date, major, creditCompleted);
		this.isStudyAbroad = false;
	}

    /**
     * constructor for International student
     * @param fname           student's first name
     * @param lname           student's last name
     * @param date            student's date of birth
     * @param major           Student's major
     * @param creditCompleted number of credits completed by the student
     * @param isStudyAbroad status
     */
    public International(String fname, String lname, String date, Major major, int creditCompleted, boolean isStudyAbroad) {
		super(fname, lname, date, major, creditCompleted);
		this.isStudyAbroad = isStudyAbroad;
	}
	/**
	 * constructor for International student
	 * @param profile         profile to profile to base student off of
	 * @param major           Student's major
	 * @param creditCompleted number of credits completed by the student
	 * @param isStudyAbroad status
	 */
	public International(Profile profile, Major major, int creditCompleted, boolean isStudyAbroad) {
		super(profile, major, creditCompleted);
		this.isStudyAbroad = isStudyAbroad;
	}


    /**
     * checks if credits enrolled is valid for international student
     * @param creditEnrolled number of credits enrolled by the student
     * @return validity
     */
    public boolean isValid(int creditEnrolled) {
    	if(isStudyAbroad) {
    		return (creditEnrolled >= 3 && creditEnrolled <= 12);
    	}
    	return (creditEnrolled >= 12 && creditEnrolled <= 24);
    }


    /**
     * discount for international student
     * @param creditsEnrolled number of credits enrolled by the student
     * @return discount
     */
    private double thisDiscount(int creditsEnrolled) {
    	if(isStudyAbroad) return fullTimeTuition;
    	return 0d;
    }

    /**
     * health insurance fee for international student
     * @return insurance fee
     */
    private double thisHealthInsuranceFee() {
    	return thisShouldBeFreeFee;
    }


    /**
     * tuition due for international student
     * @param creditsEnrolled number of credits enrolled by the student
     * @return tuition due
     */
    public double tuitionDue(int creditsEnrolled) {
    	if(!isValid(creditsEnrolled)) return 0d;
    	boolean partTime = creditsEnrolled < 12;
    	int excessCredits = (creditsEnrolled > 16) ? (creditsEnrolled-16) : 0;
    	double tuitionAmount = (fullTimeTuition + (partTimeTuitionPerCredit * excessCredits));
    	double universityFeeAmount = (universityFee);
    	double healthInsuranceFeeAmount = thisHealthInsuranceFee();
    	double discountedAmount = thisDiscount(creditsEnrolled);
    	double tuitionDue = tuitionAmount + universityFeeAmount + healthInsuranceFeeAmount - discountedAmount;
    	return (tuitionDue > 0d) ? tuitionDue : 0d;
    }
	/**
	 * Converting student to a string
	 * @return student string
	 */
	@Override
	public String studentTypeToString() {
		return "International student" + (this.isStudyAbroad ? "study abroad":"");
	}

	/**
	 * Converting student to a string for graduation format
	 * @return student string
	 */
	@Override
	public String studentTypeToStringGradFormat() {
		return "(non-resident) (international" + (this.isStudyAbroad ? "study abroad":"") + ")";
	}
}
