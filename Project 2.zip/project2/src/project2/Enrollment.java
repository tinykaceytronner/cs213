package project2;

/**
 * This class mainly adds, removes, finds, and prints students in the enrollment.
 * @author Ashika Nadella
 */
public class Enrollment {

    private EnrollStudent[] enrollStudents;
    private int size;
    public static final int NOT_FOUND = -1; // constant

    /**
     * Default Constructor to make a new Enrollment, with default size of 4.
     */
    public Enrollment() {
        enrollStudents = new EnrollStudent[4];
        size = 4;
    }
    /**
     * Count the number of students currently in the Enrollment.
     * Different from Enrollment.size() because not counting null entries.
     * @return Integer count of students currently in the enrollment.
     */
    public int studentsEnrolled() {
        int count = 0;
        for(int i = 0; i<enrollStudents.length-1; i++) {
            if(!(enrollStudents[i] == null)) count++;
        }
        return count;
    }

    /**
     * A getter method that returns the enrollment to access it in different classes.
     * @return enrollment with all students.
     */
    public EnrollStudent[] getEnrollStudents() {
        return enrollStudents;
    }
    /**
     * Setter method that sets enrollStudents.
     * @param enrollStudents enrollstudents list
     */
    public void setEnrollStudents(EnrollStudent[] enrollStudents) {
    	this.enrollStudents = enrollStudents;
    }

    /**
     * A getter method that returns the size of the enrollment to access it in different classes.
     * @return size the size of the enrollment.
     */
    public int getSize() {
        return size;
    }
    /**
     * Setter method that sets size.
     * @param size size to set
     */
    public void setSize(int size) {
    	this.size = size;
    }

    /**
     * Enrolls the student to the enrollment
     * @param studentToEnroll Student to be added to the enrollment.
     */
    public void add(EnrollStudent studentToEnroll) {
        boolean added = false;
        int z = find(studentToEnroll);
        if(z != NOT_FOUND) {
            enrollStudents[z] = studentToEnroll;
        } else {
            for (int i = 0; i < size; i++) {
                if (enrollStudents[i] == null) {
                    enrollStudents[i] = studentToEnroll;
                    added = true;
                    break;
                }
            }
            if (added != true) {
                int numOfStudents = size;
                int oldSize = size;
                size += 4;
                EnrollStudent[] newRoster = new EnrollStudent[size];
                for (int x = 0; x < oldSize; x++) {
                    newRoster[x] = enrollStudents[x];
                }
                enrollStudents = newRoster;
                enrollStudents[numOfStudents] = studentToEnroll;

            }
        }
    }
    /**
     * Removes the student from the enrollment.
     * @param studentToRemove This student will be removed from the enrollment if they are in it.
     */
    public void remove(EnrollStudent studentToRemove) {
        int index = find(studentToRemove);
        size -= 1;
        EnrollStudent[] newArray = new EnrollStudent[size];
        for (int i = 0; i < index; i++) {
            newArray[i] = enrollStudents[i];
        }
        int x = index + 1;
        while (x <= size) {
            newArray[x - 1] = enrollStudents[x];
            if (x + 1 <= size) {
                x++;
            } else {
                break;
            }
        }
        enrollStudents = newArray;
    }
    /**
     * Checks to see if the student is present in the enrollment and returns true if the student is present.
     * @param studentToCheck The student to search for in the roster.
     * @return true when student is in roster, false when student is not in roster.
     */
    public boolean contains(EnrollStudent studentToCheck) {
        return (find(studentToCheck) != NOT_FOUND);
    }
    /**
     * Finds the student in the enrollment and returns their index.
     * @param studentToFind search the roster for this student.
     * @return i index of the student, or NOT_FOUND = -1 when the student is not found in the enrollment.
     */
    public int find(EnrollStudent studentToFind) {
        for (int i = 0; i < getSize(); i++) {
            if (studentToFind.equals(enrollStudents[i])) {
                return i;
            }
        }
        return NOT_FOUND;
    }

    /**
     * Prints the students in enrollment in the order they are enrolled
     */
    public void print() {
        for (int x = 0; x < getSize(); x++) {
            if (enrollStudents[x] != null) {
                System.out.println(enrollStudents[x]);
            }
        }
    }
}


