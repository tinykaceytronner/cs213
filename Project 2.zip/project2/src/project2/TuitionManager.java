package project2;

import java.io.File;
import java.io.FileNotFoundException;
import java.text.DecimalFormat;
import java.util.Scanner;
import java.util.StringTokenizer;
/**
* This class gets the input from the user and responds accordingly by calling upon other classes.
* Uses Scanner and String Tokenizer to get the input.
* @author Ashika Nadella, Christopher Blanchard
*/

public class TuitionManager {
    /**
     * Adds a student to the Roster.
     * Used in the run method.
     * @param fname   the first name of the student to add
     * @param lname   the last name of the student to add
     * @param dob     the date of birth of the student to add
     * @param major   the major of the student to add
     * @param credits the current credits completed of the student to add
     * @param obj     The Roster which will add the student.
     */
    private void AR(String fname, String lname, String dob, String major, String credits, Roster obj, boolean printDisplay, String delim) {
        major = major.toUpperCase();
        if (!Major.isStringMajor(major)) {
            System.out.println("Major code invalid: " + major);
            return;
        }
        Major majorToAdd = Major.valueOf(major);
        Date dobToAdd = new Date(dob);
        if (!dobToAdd.isValid()) {
            System.out.println("DOB invalid: " + dobToAdd + " not a valid calendar date!");
            return;
        }
        if (dobToAdd.isTodayorFuture() || dobToAdd.birthDateAge() < 16) {
            System.out.println("DOB invalid: " + dobToAdd + " younger than 16 years old.");
            return;
        }
        try {
            Integer.parseInt(credits);
        } catch (Exception e) {
            System.out.println("Credits completed invalid: not an integer!");
            return;
        }
        if (Integer.parseInt(credits) < 0) {
            System.out.println("Credits completed invalid: cannot be negative!");
            return;
        }
        Resident studentToAdd = new Resident(fname, lname, dob, majorToAdd, Integer.parseInt(credits));
        if (obj.contains(studentToAdd)) {
            System.out.println(studentToAdd.getProfile() + " is already in the roster.");
            return;
        }
        obj.add(studentToAdd);
        if(printDisplay) System.out.println(studentToAdd.getProfile() + " added to the roster.");
    }
    /**
     * Adds a Non resident student to the Enrollment.
     * Used in the run method.
     * @param fname   the first name of the student to add
     * @param lname   the last name of the student to add
     * @param dob     the date of birth of the student to add
     * @param major   the major of the student to add
     * @param credits the current credits completed of the student to add
     * @param obj     The Roster which will add the student.
     */
    private void AN(String fname,String lname,String dob,String major,String credits, Roster obj, boolean printDisplay, String delim) {
        major = major.toUpperCase();
        if (!Major.isStringMajor(major)) {
            System.out.println("Major code invalid: " + major);
            return;
        }
        Major majorToAdd = Major.valueOf(major);
        Date dobToAdd = new Date(dob);
        if (!dobToAdd.isValid()) {
            System.out.println("DOB invalid: " + dobToAdd + " not a valid calendar date!");
            return;
        }
        if (dobToAdd.isTodayorFuture() || dobToAdd.birthDateAge() < 16) {
            System.out.println("DOB invalid: " + dobToAdd + " younger than 16 years old.");
            return;
        }
        try {
            Integer.parseInt(credits);
        } catch (Exception e) {
            System.out.println("Credits completed invalid: not an integer!");
            return;
        }
        if (Integer.parseInt(credits) < 0) {
            System.out.println("Credits completed invalid: cannot be negative!");
            return;
        }
        NonResident studentToAdd = new NonResident(fname, lname, dob, majorToAdd, Integer.parseInt(credits));
        if (obj.contains(studentToAdd)) {
            System.out.println(studentToAdd.getProfile() + " is already in the roster.");
            return;
        }
        obj.add(studentToAdd);
        if(printDisplay) System.out.println(studentToAdd.getProfile() + " added to the roster.");
    }
    /**
     * Adds a tristate student to the Enrollment.
     * Used in the run method.
     * @param fname   the first name of the student to add
     * @param lname   the last name of the student to add
     * @param dob     the date of birth of the student to add
     * @param major   the major of the student to add
     * @param credits the current credits completed of the student to add
     * @param obj     The Roster which will add the student.
     */
    private void AT(String fname, String lname, String dob, String major, String credits, String state,Roster obj, boolean printDisplay, String delim) {
        major = major.toUpperCase();
        if (!Major.isStringMajor(major)) {
            System.out.println("Major code invalid: " + major);
            return;
        }
        Major majorToAdd = Major.valueOf(major);
        Date dobToAdd = new Date(dob);
        if (!dobToAdd.isValid()) {
            System.out.println("DOB invalid: " + dobToAdd + " not a valid calendar date!");
            return;
        }
        if (dobToAdd.isTodayorFuture() || dobToAdd.birthDateAge() < 16) {
            System.out.println("DOB invalid: " + dobToAdd + " younger than 16 years old.");
            return;
        }
        try {
            Integer.parseInt(credits);
        } catch (Exception e) {
            System.out.println("Credits completed invalid: not an integer!");
            return;
        }
        if (Integer.parseInt(credits) < 0) {
            System.out.println("Credits completed invalid: cannot be negative!");
            return;
        }
        TriState studentToAdd = new TriState(fname, lname, dob, majorToAdd, Integer.parseInt(credits), state);
        if(!studentToAdd.stateValid()) {
            System.out.println(studentToAdd.getState() + ": Invalid state code.");
            return;
        }
        if (obj.contains(studentToAdd)) {
            System.out.println(studentToAdd.getProfile() + " is already in the roster.");
            return;
        }
        obj.add(studentToAdd);
        if(printDisplay) System.out.println(studentToAdd.getProfile() + " added to the roster.");
    }
    /**
     * Adds a international student to the Enrollment.
     * Used in the LS method.
     * @param fname   the first name of the student to add
     * @param lname   the last name of the student to add
     * @param dob     the date of birth of the student to add
     * @param major   the major of the student to add
     * @param credits the current credits completed of the student to add
     * @param isStudyAbroad whether or not this student will be in the study abroad program.
     * @param obj     The Roster which will add the student.
     */
    private void AI(String fname, String lname, String dob, String major, String credits, String studyAbroad, Roster obj, boolean printDisplay, String delim) {
    	boolean isStudyAbroad = false;
    	if(studyAbroad.compareToIgnoreCase("true")  == 0) isStudyAbroad = true;
    	if(studyAbroad.compareToIgnoreCase("false")  == 0) isStudyAbroad = false;
        major = major.toUpperCase();
        if (!Major.isStringMajor(major)) {
            System.out.println("Major code invalid: " + major);
            return;
        }
        Major majorToAdd = Major.valueOf(major);
        Date dobToAdd = new Date(dob);
        if (!dobToAdd.isValid()) {
            System.out.println("DOB invalid: " + dobToAdd + " not a valid calendar date!");
            return;
        }
        if (dobToAdd.isTodayorFuture() || dobToAdd.birthDateAge() < 16) {
            System.out.println("DOB invalid: " + dobToAdd + " younger than 16 years old.");
            return;
        }
        try {
            Integer.parseInt(credits);
        } catch (Exception e) {
            System.out.println("Credits completed invalid: not an integer!");
            return;
        }
        if (Integer.parseInt(credits) < 0) {
            System.out.println("Credits completed invalid: cannot be negative!");
            return;
        }
        International studentToAdd = new International(fname, lname, dob, majorToAdd, Integer.parseInt(credits), isStudyAbroad);
        if (obj.contains(studentToAdd)) {
            System.out.println(studentToAdd.getProfile() + " is already in the roster.");
            return;
        }
        obj.add(studentToAdd);
        if(printDisplay) System.out.println(studentToAdd.getProfile() + " added to the roster.");
    }	
    /**
     * Tries to remove a student from the Roster.
     * Used in the run method.
     * @param fname the first name of the student
     * @param lname the last name of the student
     * @param dob   the date of birth of the student
     * @param obj   The Roster which will have a student removed.
     */
    private void R(StringTokenizer a, Roster obj) {
    	if(a.countTokens() != 3)  {
            System.out.println("Missing data in command line.");
            return;
        }
        if (obj.studentsInRoster() == 0) {
            System.out.println("Student roster is empty!");
            return;
        }
        String fname = a.nextToken("\s+");
        String lname = a.nextToken("\s+");
        String dob = a.nextToken("\s+");
        boolean g = false;
        Profile t = new Profile(fname, lname, dob);
        for (int i = 0; i < obj.getSize(); i++) {
            if (obj.getRoster()[i] == null) {
                break;
            }
            Student v = (obj.getRoster()[i]);
            g = v.getProfile().equals(t);
            if (g == true) {
                obj.remove(obj.getRoster()[i]);
                System.out.println(fname + " " + lname + " " + dob + " removed " +
                        "from the roster.");
                break;
            }
        }
        if (g == false) {
            System.out.println(fname + " " + lname + " " + dob + " is not in the roster.");
        }
    }
    /**
     * Sorts students in the roster by their last names, first names, and dobs.
     * Used in the run method.
     * @param obj The Roster which will be printed.
     */
    private void P(StringTokenizer a, Roster obj) {
    	if(a.hasMoreTokens()) {
            System.out.println("Too many arguments.");
            return;
    	}
        if (obj.studentsInRoster() == 0) {
            System.out.println("Student roster is empty!");
            return;
        }
        System.out.println("* Student roster sorted by last name, first name, DOB **");
        obj.print();
        System.out.println("* end of roster **");
    }
    /**
     * Sorts students in the roster by their standing.
     * Used in the run method.
     * @param obj The Roster which will be printed.
     */
    private void PS(StringTokenizer a, Roster obj) {
    	if(a.hasMoreTokens()) {
            System.out.println("Too many arguments.");
            return;
    	}
        if (obj.studentsInRoster() == 0) {
            System.out.println("Student roster is empty!");
            return;
        }
        System.out.println("* Student roster sorted by standing **");
        obj.printByStanding();
        System.out.println("* end of roster **");
    }
    /**
     * Sorts students in the roster by their schools, and majors.
     * Used in the run method.
     * @param obj The Roster which will be printed.
     */
    private void PC(StringTokenizer a, Roster obj) {
    	if(a.hasMoreTokens()) {
            System.out.println("Too many arguments.");
            return;
    	}
        if (obj.studentsInRoster() == 0) {
            System.out.println("Student roster is empty!");
            return;
        }
        System.out.println("* Student roster sorted by school, major **");
        obj.printBySchoolMajor();
        System.out.println("* end of roster **");
    }
    /**
     * loads the student roster from external file
     * Used in the run method.
     * @param fileName The String which is the name of the attached file to read from.
     * @param obj The Roster which will be used to print.
     * @param enrollment The Enrollment which will be used to print.
     * @param studentsToAdd the students that are added
     */
    private void LS(StringTokenizer a, Roster obj, Enrollment enrollment) {
    	if(a.countTokens() != 1)  {
            System.out.println("Missing data in command line.");
            return;
        }
    	String fileName = a.nextToken("\s+");
    	File thisFile = new File(fileName);
    	try {
			Scanner sc = new Scanner(thisFile);
	    	while(sc.hasNextLine()) {
				StringTokenizer st = new StringTokenizer(sc.next());
	    		String studentType = st.nextToken(",");
	    		if	   (studentType.equals("R")&&st.countTokens()==5) AR(st.nextToken(","),st.nextToken(","),st.nextToken(","),st.nextToken(","),st.nextToken(","), obj, false, ",");
	    		else if(studentType.equals("N")&&st.countTokens()==5) AN(st.nextToken(","),st.nextToken(","),st.nextToken(","),st.nextToken(","),st.nextToken(","), obj, false, ",");
	    		else if(studentType.equals("T")) {
	    			if(st.countTokens()==5) System.out.println("Missing State Code.");
	    			if(st.countTokens()==6) AT(st.nextToken(","),st.nextToken(","),st.nextToken(","),st.nextToken(","),st.nextToken(","), st.nextToken(","), obj, false, ",");
	    		}
	    		else if(studentType.equals("I")) {
	    			if(st.countTokens()==5) AI(st.nextToken(","),st.nextToken(","),st.nextToken(","),st.nextToken(","),st.nextToken(","), "", obj, false, ",");
	    			if(st.countTokens()==6) AI(st.nextToken(","),st.nextToken(","),st.nextToken(","),st.nextToken(","),st.nextToken(","), st.nextToken(","), obj, false, ",");
	    		}
	    	}
	    	sc.close();
			System.out.println("Students loaded to the roster.");
	    	return;
		} catch (FileNotFoundException e) {
			System.out.println("File not found");
			return;
		}
    }
    /**
     * Sorts students in the roster by their last names, first names, and dobs.
     * Then prints out those which are passed in School.
     * Used in the run method.
     * @param school The particular school to print.
     * @param obj The Roster which will be printed.
     */
    private void L(String school, Roster obj) {
        if (obj.studentsInRoster() == 0) {
            System.out.println("Student roster is empty!");
            return;
        }
        boolean requestedSchoolInSystem = false;
        for (int i = 0; i < Major.values().length - 1; i++) {
            if (school.equalsIgnoreCase(Major.values()[i].getSchool())) {
                requestedSchoolInSystem = true;
                break;
            }
        }
        if (!requestedSchoolInSystem) {
            System.out.println("School doesn't exist: " + school);
            return;
        } else {
            System.out.println("* Students in " + school + " *");
            obj.printThisSchoolOnly(school);
            System.out.println("* end of list **");
        }
    }
    /**
     * Finds a Student in the given Roster, and changes their Major to the given Major.
     * @param fname Find student first name
     * @param lname Find student last name
     * @param dob   Find student dob
     * @param major Major to change
     * @param obj   Roster
     */
    private void C(String fname, String lname, String dob, String major, Roster obj) {
        major = major.toUpperCase();
        if (!Major.isStringMajor(major)) {
            System.out.println("Major code invalid: " + major);
            return;
        }
        Major newMajor = Major.valueOf(major);
        Profile lookUp = new Profile(fname, lname, dob);
        if (obj.findByProfile(lookUp) == -1) {
            System.out.println(lookUp + " is not in the roster.");
            return;
        }
        if (obj.changeMajor(obj.findByProfile(lookUp), newMajor)) {
            System.out.println(lookUp + " major changed to " + newMajor);
            return;
        }
        System.out.println(lookUp + " already has major " + newMajor);
    }
    /**
     * Enrolls a Student if they pass all the exceptions.
     * @param fname  student first name
     * @param lname  student last name
     * @param dob    student dob
     * @param credits number of credits to enroll
     * @param enroll Enrollment
     * @param obj   Roster
     */
    private void E(String fname, String lname, String dob, String credits, Roster obj,  Enrollment enroll){
        Profile stu = new Profile(fname, lname, dob);
        int creditsEnrolled = 0;
            try {
                creditsEnrolled = Integer.parseInt(credits);
            } catch (Exception e) {
                System.out.println("Credits enrolled is not an integer.");
                return;
            }
            int studentIndex = obj.findByProfile(stu);
            if(studentIndex == -1) { 
                System.out.println("Cannot enroll: " + fname + " " + lname + " " + dob + " is not in the roster ");
            	return;
            }
            if(!obj.getRoster()[studentIndex].isValid(creditsEnrolled)) {
                System.out.println("(" + obj.getRoster()[studentIndex].studentTypeToString()
                		+ ") " + creditsEnrolled + " : invalid credit hours.");
                return;
            }
            EnrollStudent student = new EnrollStudent(fname, lname, dob, creditsEnrolled);
            enroll.add(student);
            System.out.println(fname + " " + lname + " " + dob + " enrolled " + creditsEnrolled + " credits.");
        }
    /**
     * Drops a Student from the enrollment.
     * @param fname  student first name
     * @param lname  student last name
     * @param dob    student dob
     * @param drop Enrollment
     */
    private void D(String fname, String lname, String dob, Enrollment drop){
        EnrollStudent student = new EnrollStudent(fname, lname, dob, 0);
        boolean g = drop.contains(student);
        if (!g){
            System.out.println( fname + " " + lname + " " + dob + " is not enrolled.");
        } else{
            drop.remove(student);
            System.out.println( fname + " " + lname + " " + dob + " dropped.");
        }
    }
    /**
     * Displays the scholarship awarded to resident student
     * Used in the run method.
     * @param fname  student first name
     * @param lname  student last name
     * @param dob    student dob
     * @param obj The Roster which will be printed.
     * @param enrollment The Enrollment which will be printed.
     */
    private void S(String fname, String lname, String dob, String scholarship, Roster obj, Enrollment enrollment) {
        Profile profileToSearch = new Profile(fname, lname, dob);
        int studentIndex = obj.findByProfile(profileToSearch);
        if(studentIndex == -1) {
        	System.out.println( fname + " " + lname + " " + dob + " is not in the roster.");
        	return;
        }
    	int award = 0;
    	try{
        	award = Integer.parseInt(scholarship);
    	}catch(Exception e) {
        	System.out.println("Amount is not an integer.");
    		return;
    	}
    	if(award < 1 || award > 10000) {
        	System.out.println(award + ": invalid amount.");
    		return;
    	}
    	if (obj.getRoster()[studentIndex].getClass().getSimpleName().compareTo("Resident") != 0) {
        	System.out.println( fname + " " + lname + " " + dob + " (" + obj.getRoster()[studentIndex].studentTypeToString() + ") is not eligible for the scholarship.");
			return;
		}
		if(enrollment.getEnrollStudents()[enrollment.find(new EnrollStudent(profileToSearch.getFname(), profileToSearch.getLname(), profileToSearch.getDob(), 0))].getCreditsEnrolled() < 12) {
        	System.out.println( fname + " " + lname + " " + dob + " part time student is not eligible for the scholarship.");
			return;
		}
		((Resident)obj.getRoster()[studentIndex]).awardScholarship(award);
    	System.out.println( fname + " " + lname + " " + dob + ": scholarship amount updated.");
		return;
    }

    /**
     * Displays the tuition due based on the credits enrolled
     * Used in the run method.
     * @param obj The Roster which will be printed.
     * @param enrollment The Enrollment which will be printed.
     */
    private void PT(Roster obj, Enrollment enrollment) {
        if (obj.studentsInRoster() == 0) {
            System.out.println("Student roster is empty!");
            return;
        }
    	if(enrollment.getSize() == 0) {
        	System.out.println("** No Students enrolled! **");
    		return;
    	}
    	System.out.println("** Tuition due **");
    	for(int i = 0; i < enrollment.getSize(); i++) {
    		if(enrollment.getEnrollStudents()[i] == null) continue;
    		EnrollStudent studentToPrint = enrollment.getEnrollStudents()[i];
    		DecimalFormat tuitionFormat = new DecimalFormat("$#,##0.00");
        	System.out.println(studentToPrint.getProfile().getFname() + " " + studentToPrint.getProfile().getLname()
        			+ " " + studentToPrint.getProfile().getDob() + " (" + obj.getRoster()[obj.findByProfile(studentToPrint.getProfile())].studentTypeToString()
        			+ ") enrolled " + studentToPrint.getCreditsEnrolled() + " credits: tuition due: "
        			+ tuitionFormat.format(obj.getRoster()[obj.findByProfile(studentToPrint.getProfile())].tuitionDue(studentToPrint.getCreditsEnrolled())));
    	}
    	System.out.println("* end of tuition due *");
    }
    /**
     * Prints the students in enrollment in the order they are enrolled.
     * Used in the run method.
     * @param object The Enrollment which will be printed.
     */
    private void PE(Enrollment object) {
        if (object.studentsEnrolled() == 0) {
            System.out.println("Enrollment is empty!");
            return;
        }
        System.out.println("** Enrollment **");
        object.print();
        System.out.println("* end of enrollment *");
    }
    /**
     * Calculates the total number of credits completed by students in roster.
     * Prints students who have 120 or more credits completed.
     * @param student roster from which students' credits are checked
     * @param find The Enrollment from which students' credits are checked
     */
    private void SE(Roster student,  Enrollment find){
    	System.out.println("Credit completed has been updated.");
        System.out.println("** list of students eligible for graduation **");
        int  creditsDone = 0;
        int creditsEnrolled = 0;
        int totalCredits = 0;
        String fname;
        String lname;
        String dob;
        for (int i = 0; i < student.getSize(); i++) {
            if (student.getRoster()[i] == null){
                return;
            }
            creditsDone = student.getRoster()[i].getCreditsCompleted() ;
            Profile stu = student.getRoster()[i].getProfile();
            fname = stu.getFname();
            lname = stu.getLname();
            dob = stu.getDob();
            EnrollStudent s = new EnrollStudent(fname, lname, dob, 0);
            if(find.contains(s)){
                int index = find.find(s);
                creditsEnrolled = find.getEnrollStudents()[index].getCreditsEnrolled();
                totalCredits = creditsDone + creditsEnrolled;
                student.getRoster()[i].setCreditsCompleted(totalCredits);
            } else{
                totalCredits = creditsDone;
                student.getRoster()[i].setCreditsCompleted(totalCredits);
            }
            if (totalCredits >= 120 ){
                System.out.println(student.getRoster()[i].getProfile() + " ("
                        + student.getRoster()[i].getMajor().getCode() + " " + student.getRoster()[i].getMajor() + " "
                        + student.getRoster()[i].getMajor().getSchool() + ") credits completed: "
                        + student.getRoster()[i].getCreditsCompleted() + " ("
                        + student.getRoster()[i].getStanding(student.getRoster()[i]) + ")" + student.getRoster()[i].studentTypeToStringGradFormat());
            }
        }
    }
    /**
     * Gets the input from the user and responds to it by calling upon different methods
     * Responds to "A", "R", "P", "PS", "PC", "L", "C", and "Q"
     * Used in the runProject1 class.
     */
    public void run() {
        System.out.println("Tuition Manager running...\n");
        Roster obj = new Roster();
        Enrollment enroll = new Enrollment();
        Scanner scan = new Scanner(System.in);
        String read = scan.nextLine();
        String input = "";
        while (!read.contentEquals("Q")) {
            StringTokenizer a = new StringTokenizer(read, "\s+");
            try {
                input = a.nextToken("\s+"); } catch (Exception e) {
                input = ""; }
            if (input.contentEquals("AR")) {
            	if(a.countTokens()==5) AR(a.nextToken("\s+"),a.nextToken("\s+"),a.nextToken("\s+"),a.nextToken("\s+"),a.nextToken("\s+"),obj,true,"\s+");
            	else System.out.println("Missing data in line command."); }
            else if(input.contentEquals("AN")) { 
            	if(a.countTokens()==5) AN(a.nextToken("\s+"),a.nextToken("\s+"),a.nextToken("\s+"),a.nextToken("\s+"),a.nextToken("\s+"),obj,true,"\s+");
            	else System.out.println("Missing data in line command."); }
            else if(input.contentEquals("AT")) {
            	if(a.countTokens()==5) System.out.println("Missing state code.");
            	else if(a.countTokens()==6) AT(a.nextToken("\s+"),a.nextToken("\s+"),a.nextToken("\s+"),a.nextToken("\s+"),a.nextToken("\s+"),a.nextToken("\s+"),obj,true,"\s+");
            	else System.out.println("Missing data in line command."); }
            else if(input.contentEquals("AI")) {
            	if(a.countTokens()==5) AI(a.nextToken("\s+"),a.nextToken("\s+"),a.nextToken("\s+"),a.nextToken("\s+"),a.nextToken("\s+"),"",obj,true,"\s+");
            	else if(a.countTokens()==6) AI(a.nextToken("\s+"),a.nextToken("\s+"),a.nextToken("\s+"),a.nextToken("\s+"),a.nextToken("\s+"),a.nextToken("\s+"),obj,true,"\s+");
            	else System.out.println("Missing data in line command."); }
            else if(input.contentEquals("R")) R(a,obj);
            else if(input.contentEquals("P")) P(a,obj);
            else if(input.contentEquals("PS")) PS(a,obj);
            else if(input.contentEquals("PC")) PC(a,obj);
            else if(input.contentEquals("L")) { 
            	if(a.countTokens()==1)L(a.nextToken("\s+"),obj);
            	else System.out.println("Missing data in line command."); }
            else if(input.contentEquals("LS")) LS(a,obj,enroll);
            else if(input.contentEquals("C")) {
            	if(a.countTokens()==4) C(a.nextToken("\s+"),a.nextToken("\s+"),a.nextToken("\s+"),a.nextToken("\s+"),obj);
            	else System.out.println("Missing data in line command."); }
            else if(input.contentEquals("E")) {
            	if(a.countTokens()==4) E(a.nextToken("\s+"),a.nextToken("\s+"),a.nextToken("\s+"),a.nextToken("\s+"),obj,enroll);
            	else System.out.println("Missing data in line command."); }
            else if(input.contentEquals("D")) {
            	if(a.countTokens()==3) D(a.nextToken("\s+"),a.nextToken("\s+"),a.nextToken("\s+"),enroll);
            	else System.out.println("Missing data in line command."); }
            else if(input.contentEquals("S")) {
            	if(a.countTokens()==4) S(a.nextToken("\s+"),a.nextToken("\s+"),a.nextToken("\s+"),a.nextToken("\s+"),obj,enroll);
            	else if(a.countTokens()==3) S(a.nextToken("\s+"),a.nextToken("\s+"),a.nextToken("\s+"),"0",obj,enroll);
            	else System.out.println("Missing data in line command."); }
            else if(input.contentEquals("PE")) {
            	if(a.countTokens()==0) PE(enroll);
            	else System.out.println("Missing data in line command."); }
            else if(input.contentEquals("PT")) { 
            	if(a.countTokens()==0) PT(obj,enroll);
            	else System.out.println("Missing data in line command."); }
            else if(input.contentEquals("SE")) { 
            	if(a.countTokens()==0) SE(obj,enroll);
            	else System.out.println("Missing data in line command."); }
        	else if(!input.contentEquals("")) System.out.println(input + " is an invalid command!");
            read = scan.nextLine(); }
        System.out.println("Tuition Manager terminated.");
        scan.close();
    }
}

    
