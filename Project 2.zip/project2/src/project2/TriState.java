package project2;
/**
* This class performs discount, and isResident functions mainly for tristate student
* @author Christopher Blanchard
*/
public class TriState extends NonResident{
	public final static double NYDiscount = 4000d;
	public final static double CTDiscount = 5000d;
	private String state;
	  /**
	   * Getter method that returns the state of the student to access it in different classes.
	   * @return state
	   */
	public String getState() {
		return state;
	} 
		/**
	   * Setter method that sets the state of the student to access it in different classes.
	   * @param state
	   */
	public void setState(String state) {
		this.state = state.toUpperCase();
	}
	  /**
	   * constructor for resident student
	   * @param fname           student's first name
	   * @param lname           student's last name
	   * @param date            student's date of birth
	   * @param major           Student's major
	   * @param creditCompleted number of credits completed by the student
	   * @param state
	   */
    public TriState(String fname, String lname, String date, Major major, int creditCompleted, String state) {
		super(fname, lname, date, major, creditCompleted);
		this.state = state.toUpperCase();
	}

    /**
     * discount for NY student
     * @return discount as true or false
     */
    public boolean getsNYDiscount() {
    	return (this.state.compareTo("NY") == 0);
    }

    /**
     * discount for CT student
     * @return discount as true or false
     */
    public boolean getsCTDiscount() {
    	return (this.state.compareTo("CT") == 0);
    }
    /**
     * sees if the state is valid
     * @return validity as true or false
     */
    public boolean stateValid() {
    	return getsNYDiscount() || getsCTDiscount();
    }
    /**
     * discount for tristate student
     * @param creditsEnrolled number of credits enrolled by the student
     * @return discount
     */
    private double thisDiscount(int creditsEnrolled) {
    	if(creditsEnrolled < 12) return 0d;
    	if(getsCTDiscount()) return CTDiscount;
    	if(getsNYDiscount()) return NYDiscount;
    	return 0d;
    }

    /**
     * health insurance fee for tristate student
     * @return insurance fee
     */
    private double thisHealthInsuranceFee() {
    	return 0d;
    }


    /**
     * tuition due for tristate student
     * @param creditsEnrolled number of credits enrolled by the student
     * @return tuition due
     */
    public double tuitionDue(int creditsEnrolled) {
    	if(!isValid(creditsEnrolled)) return 0d;
    	boolean partTime = creditsEnrolled < 12;
    	int excessCredits = (creditsEnrolled > 16) ? (creditsEnrolled-16) : 0;
    	double tuitionAmount = (partTime) ? (partTimeTuitionPerCredit * creditsEnrolled) : (fullTimeTuition + (partTimeTuitionPerCredit * excessCredits));
    	double universityFeeAmount = (partTime) ? (universityFee * partTimeUniversityFeePercentage) : (universityFee);
    	double healthInsuranceFeeAmount = thisHealthInsuranceFee();
    	double discountedAmount = thisDiscount(creditsEnrolled);
    	double tuitionDue = tuitionAmount + universityFeeAmount + healthInsuranceFeeAmount - discountedAmount;
    	return (tuitionDue > 0d) ? tuitionDue : 0d;
    }
    /**
     * @return String format
     */
	@Override
	public String studentTypeToString() {
		return "Tri-state " + this.state;
	}
    /**
     * @return String format
     */
	@Override
	public String studentTypeToStringGradFormat() {
		return "(non-resident) (tri-state:" + this.state + ")";
	}
    /**
     * is this amount of credits valid?
     * @param creditEnrolled number of credits enrolled by the student
     * @return if this is valid or not
     */
    public boolean isValid(int creditEnrolled) {
    	return (creditEnrolled >= 3 && creditEnrolled <= 24);
    }
    public static void main(String[] args) {
    	TriState test1 = new TriState("A","A","01/01/2000",Major.BAIT,0,"NY");
		for(int i = -5; i<=30; i++) {
	    	System.out.println(i + ": " + test1.tuitionDue(i));
		}
    	TriState test2 = new TriState("A","A","01/01/2000",Major.BAIT,0,"CT");
		for(int i = -5; i<=30; i++) {
	    	System.out.println(i + ": " + test2.tuitionDue(i));
		}
    	TriState test3 = new TriState("A","A","01/01/2000",Major.BAIT,0,"ct");
		for(int i = -5; i<=30; i++) {
	    	System.out.println(i + ": " + test3.tuitionDue(i));
		}
    	TriState test4 = new TriState("A","A","01/01/2000",Major.BAIT,0,"nj");
		for(int i = -5; i<=30; i++) {
	    	System.out.println(i + ": " + test4.tuitionDue(i));
		}
	}
    
}
