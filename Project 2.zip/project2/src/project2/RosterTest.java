
package project2;

import static org.junit.Assert.*;

import org.junit.*;
public class RosterTest {

	@Test
	public void testAdd() {
		var international = new International("Girl", "Boss", "6/6/2006", Major.CS, 0);
		var tristate = new TriState("Girl", "Boss", "6/6/2006", Major.CS, 0, "NY");
		var roster = new Roster();
		var testCase1 = roster.add(international); 
		var testCase2 = roster.add(international); // will not work because this student has already been added.
		var testCase3 = roster.add(tristate); 
		var testCase4 = roster.add(tristate); // will not work because this student has already been added.
		assertTrue(testCase1 && !testCase2 && testCase3 && !testCase4);
	}

	@Test
	public void testRemove() {
		International international = new International("Girl", "Boss", "6/6/2006", Major.CS, 0);
		TriState tristate = new TriState("Girl", "Boss", "6/6/2006", Major.CS, 0, "NY");
		Roster roster = new Roster();
		boolean testCase1 = roster.remove(international); // will not work because the student is not in the roster.
		boolean testCase2 = roster.remove(tristate); // will not work because the student is not in the roster.
		roster.add(international);
		roster.add(tristate);
		boolean testCase3 = roster.remove(international);
		boolean testCase4 = roster.remove(tristate);
		assertTrue(!testCase1 && !testCase2 && testCase3 && testCase4);
	}

}
