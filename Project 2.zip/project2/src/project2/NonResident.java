package project2;


/**
* This class performs tuitiondue, isResident functions mainly for nonresident student
* @author Christopher Blanchard
*/
public class NonResident extends Student {
	public final static double fullTimeTuition = 29737d;
	public final static double partTimeTuitionPerCredit = 966d;


	  /**
	   * constructor for nonresident student
	   * @param fname           student's first name
	   * @param lname           student's last name
	   * @param date            student's date of birth
	   * @param major           Student's major
	   * @param creditCompleted number of credits completed by the student
	   */
	public NonResident(String fname, String lname, String date, Major major, int creditCompleted) {
		super(fname, lname, date, major, creditCompleted);
	}
	  /**
	   * discount for nonresident student
	   * @param creditsEnrolled number of credits enrolled by the student
	   * @return discount
	   */
    private double thisDiscount(int creditsEnrolled) {
    	return 0d;
    }

    /**
     * health insurance fee for nonresident student
     * @return insurance fee
     */
    private double thisHealthInsuranceFee() {
    	return 0d;
    }

    /**
     * tuition due for nonresident student
     * @param creditsEnrolled number of credits enrolled by the student
     * @return tuition due
     */
    public double tuitionDue(int creditsEnrolled) {
    	if(!isValid(creditsEnrolled)) return 0d;
    	boolean partTime = creditsEnrolled < 12;
    	int excessCredits = (creditsEnrolled > 16) ? (creditsEnrolled-16) : 0;
    	double tuitionAmount = (partTime) ? (partTimeTuitionPerCredit * creditsEnrolled) : (fullTimeTuition + (partTimeTuitionPerCredit * excessCredits));
    	double universityFeeAmount = (partTime) ? (universityFee * partTimeUniversityFeePercentage) : (universityFee);
    	double healthInsuranceFeeAmount = thisHealthInsuranceFee();
    	double discountedAmount = thisDiscount(creditsEnrolled);
    	double tuitionDue = tuitionAmount + universityFeeAmount + healthInsuranceFeeAmount - discountedAmount;
    	return (tuitionDue > 0d) ? tuitionDue : 0d;
    }
    /**
     * determining residency for nonresident student
     * @return residency status as true or false
     */
    public boolean isResident() {
    	return false;
    }
    /**
     * @return String format
     */
	@Override
	public String studentTypeToString() {
		return "Non-Resident";
	}
    /**
     * @return String format
     */
	@Override
	public String studentTypeToStringGradFormat() {
		return "(non-resident)";
	}
    /**
     * is this amount of credits valid?
     * @param creditEnrolled number of credits enrolled by the student
     * @return if this is valid or not
     */
    public boolean isValid(int creditEnrolled) {
    	return (creditEnrolled >= 3 && creditEnrolled <= 24);
    }
    public static void main(String[] args) {
		NonResident test = new NonResident("A","A","01/01/2000",Major.BAIT,0);
		for(int i = -5; i<=30; i++) {
	    	System.out.println(i + ": " + test.tuitionDue(i));
		}
	}
}
