package project2;

import static org.junit.Assert.*;

import org.junit.*;

public class DateTest {

	@Test
	public void testIsValid() {
		var testCase1 = new Date("00/00/0000"); // Will 0 be handled properly?
		var testCase2 = new Date("13/12/2000"); // Will out-of-bounds month be handled properly?
		var testCase3 = new Date("01/32/2000"); // Will out-of-bounds day be handled properly?
		var testCase4 = new Date("-01/12/2000"); // Will negative month be handled properly?
		var testCase5 = new Date("02/29/2001"); // Will out-of-bounds day on non-leap year be handled properly?
		var testCase6 = new Date("02/29/2000"); // Will 29 day on leap year be handled properly?
		var testCase7 = new Date("09/23/2022"); // Will my niece's birthday work?
		assertTrue(!testCase1.isValid() && !testCase2.isValid() && !testCase3.isValid() && !testCase4.isValid() && !testCase5.isValid() && testCase6.isValid() && testCase7.isValid());
	}

}