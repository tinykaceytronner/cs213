package project2;

import static org.junit.Assert.*;
import org.junit.*;

public class InternationalTest {

	@Test
	public void testTuitionDue() {
		var six = 6;
		var thirteen = 13;
		var eighteen = 18;
		var studyAbroad_T = new International("Girl", "Boss", "6/6/2006", Major.CS, 0, true);
		var studyAbroad_F = new International("Girl", "Boss", "6/6/2006", Major.CS, 0, false);
		var bool1 = studyAbroad_T.tuitionDue(six) == Student.thisShouldBeFreeFee + Student.universityFee;
		var bool2 = studyAbroad_F.tuitionDue(thirteen) == Student.thisShouldBeFreeFee + Student.universityFee + NonResident.fullTimeTuition;
		var bool3 = studyAbroad_F.tuitionDue(eighteen) == Student.thisShouldBeFreeFee + Student.universityFee + NonResident.fullTimeTuition + (eighteen-16)*NonResident.partTimeTuitionPerCredit;
		assertTrue(bool1 && bool2 && bool3);
	}

}