package project2;


/**
* This class performs tuitiondue, isResident functions mainly for resident student
* @author Christopher Blanchard
*/
public class Resident extends Student {
	public final static double fullTimeTuition = 12536d;
	public final static double partTimeTuitionPerCredit = 404d;
	private int scholarship;


	  /**
	   * Getter method that returns the scholarship of the student to access it in different classes.
	   * @return scholarship
	   */
	public int getScholarship() {
		return scholarship;
	}

	  /**
	   * Setter method that sets the scholarship of the student to access it in different classes.
	   * @param scholarship
	   */
	public void setScholarship(int scholarship) {
		this.scholarship = scholarship;
	}

	  /**
	   * awards the scholarship of the student to access it in different classes.
	   * @param amount to award
	   */
    public void awardScholarship(int amount) {
    	this.scholarship += amount;
    }

    /**
     * constructor for resident student
     * @param fname           student's first name
     * @param lname           student's last name
     * @param date            student's date of birth
     * @param major           Student's major
     * @param creditCompleted number of credits completed by the student
     */
    public Resident(String fname, String lname, String date, Major major, int creditCompleted) {
		super(fname, lname, date, major, creditCompleted);
		this.scholarship = 0;
	}
    /**
     * constructor for resident student
     * @param fname           student's first name
     * @param lname           student's last name
     * @param date            student's date of birth
     * @param major           Student's major
     * @param creditCompleted number of credits completed by the student
     * @param scholarship amount to award
     */
    public Resident(String fname, String lname, String date, Major major, int creditCompleted, int scholarship) {
		super(fname, lname, date, major, creditCompleted);
		this.scholarship = scholarship;
	}
    /**
     * discount for resident student
     * @param creditsEnrolled number of credits enrolled by the student
     * @return discount
     */
    private double thisDiscount(int creditsEnrolled) {
    	return scholarship;
    }
    /**
     * health insurance fee for resident student
     * @return insurance fee
     */
    private double thisHealthInsuranceFee() {
    	return 0d;
    }
    /**
     * tuition due for resident student
     * @param creditsEnrolled number of credits enrolled by the student
     * @return tuition due
     */
    public double tuitionDue(int creditsEnrolled) {
    	if(!isValid(creditsEnrolled)) return 0d;
    	boolean partTime = creditsEnrolled < 12;
    	int excessCredits = (creditsEnrolled > 16) ? (creditsEnrolled-16) : 0;
    	double tuitionAmount = (partTime) ? (partTimeTuitionPerCredit * creditsEnrolled) : (fullTimeTuition + (partTimeTuitionPerCredit * excessCredits));
    	double universityFeeAmount = (partTime) ? (universityFee * partTimeUniversityFeePercentage) : (universityFee);
    	double healthInsuranceFeeAmount = thisHealthInsuranceFee();
    	double discountedAmount = thisDiscount(creditsEnrolled);
    	double tuitionDue = tuitionAmount + universityFeeAmount + healthInsuranceFeeAmount - discountedAmount;
    	return (tuitionDue > 0d) ? tuitionDue : 0d;
    }
    /**
     * determining residency for resident student
     * @return residency status as true or false
     */
    public boolean isResident() {
    	return true;
    }
    /**
     * @return String format
     */
	@Override
	public String studentTypeToString() {
		return "Resident";
	}
    /**
     * @return String format
     */
	@Override
	public String studentTypeToStringGradFormat() {
		return "(resident)";
	}
    /**
     * is this amount of credits valid?
     * @param creditEnrolled number of credits enrolled by the student
     * @return if this is valid or not
     */
    public boolean isValid(int creditEnrolled) {
    	return (creditEnrolled >= 3 && creditEnrolled <= 24);
    }
    public static void main(String[] args) {
		Resident test = new Resident("A","A","01/01/2000",Major.BAIT,0,0);
		for(int i = -5; i<=30; i++) {
	    	System.out.println(i + ": " + test.tuitionDue(i));
		}
	}
}
