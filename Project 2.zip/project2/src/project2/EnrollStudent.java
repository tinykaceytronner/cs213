package project2;
/**
 * This class creates new students to enroll using their profile, and credits enrolled.
 * @author Ashika Nadella
 */
public class EnrollStudent {
    private Profile profile;
    private int creditsEnrolled;

    /**
     * Getter method that returns the credits enrolled by the student to access it in different classes.
     * @return credits enrolled
     */
    public int getCreditsEnrolled() {
        return creditsEnrolled;
    }
    /**
     * Setter method that sets credits enrolled.
     * @param creditsEnrolled credits enrolled
     */
    public void setCreditsEnrolled(int creditsEnrolled) {
        this.creditsEnrolled = creditsEnrolled;
    }
    /**
     * Getter method that returns the profile of the student to access it in different classes.
     * @return profile which contains last name, first name, and date of birth of the student.
     */
    public Profile getProfile() {
        return profile;
    }
    /**
     * Setter method that sets profile.
     */
    public void setProfile(Profile profile) {
        this.profile = profile;
    }

    /**
     * A student constructor that creates a instance/object of the Enrollstudent class using the student's data.
     * @param fname           student's first name
     * @param lname           student's last name
     * @param dob            student's date of birth
     * @param creditsEnrolled number of credits enrolled by the student
     */
    public EnrollStudent(String fname, String lname, String dob, int creditsEnrolled){
        this.profile = new Profile(fname, lname, dob);
        this.creditsEnrolled = creditsEnrolled;
    }

    /**
     * Compares two student objects' profiles to see if they are equal.
     * Overrides the equal method
     * @param obj object that is compared to
     * @return true if both objects are same and false if the object is different or not EnrollStudent type.
     */
    @Override
    public boolean equals(Object obj) {
        if (obj instanceof EnrollStudent) {
            EnrollStudent data = (EnrollStudent) obj;
            boolean profiles = data.profile.equals(this.profile);
           // boolean credit = data.creditsEnrolled == this.creditsEnrolled;
            return profiles;
                    //&& credit;
        }
        return false;
    }
    /**
     * converts the student's profile, and credits enrolled to a string.
     * Overrides the string method
     * @return string of profile, and credits completed.
     */
    @Override
    public String toString() {
        return profile + ": credits enrolled: " + creditsEnrolled;
    }
}
