package project2;
/**
 * This class creates students' profiles using their first name,last name,and date of birth.
 * @author Ashika Nadella
 */
public class Profile implements Comparable<Profile> {
    private String lname;
    private String fname;
    private Date dob;

    /**
     * Getter method that returns the date of birth of the student to access it in different classes.
     * @return Date of birth in string form
     */
    public String getDob() {
        return dob.toString();
    }

    /**
     * Getter method that returns the first name of the student to access it in different classes.
     * @return first name of the student
     */
    public String getFname() {
        return fname;
    }

    /**
     * Getter method that returns the last name of the student to access it in different classes.
     * @return last name of the student
     */
    public String getLname() {
        return lname;
    }
    /**
     * A profile constructor that creates a instance/object of the profile class using the student's data.
     * @param fname student's first name
     * @param lname student's last name
     * @param dob   student's date of birth
     */
    public Profile(String fname, String lname, String dob) {

        if (fname.length() != 1) fname = fname.substring(0, 1).toUpperCase() + fname.substring(1).toLowerCase();
        if (lname.length() != 1) lname = lname.substring(0, 1).toUpperCase() + lname.substring(1).toLowerCase();
        if (fname.length() == 1) fname = fname.toUpperCase();
        if (lname.length() == 1) lname = lname.toUpperCase();

        this.fname = fname;
        this.lname = lname;
        this.dob = new Date(dob);
    }

    /**
     * Compares two student objects' last names, first names, date of births to see if they are equal.
     * Overrides the equal method
     * @param obj object that is compared to
     * @return true if both objects are same and false if the object is different or not profile type.
     */
    @Override
    public boolean equals(Object obj) {
        if (obj instanceof Profile) {
            Profile data = (Profile) obj;
            boolean lastName = data.lname.equals(this.lname);
            boolean firstName = data.fname.equals(this.fname);
            boolean dateOB = data.dob.equals(this.dob);
            return lastName && firstName && dateOB;
        }
        return false;
    }

    /**
     * converts the student's first name, last name, and date of birth to a string.
     * Overrides the string method
     * @return string of first name, last name, and date of birth.
     */
    @Override
    public String toString() {
        return fname + " " + lname + " " + dob;
    }

    /**
     * compares two students' last names, first names and date of births to sort in lexicographical order
     * Overrides the compareTo method
     * @return 0 if profiles are same, positive number if the other's profile comes before,negative if it comes after.
     */
    @Override
    public int compareTo(Profile other) {
        int num = lname.compareTo(other.lname);
        if (num != 0) return num;
        num = fname.compareTo(other.fname);
        if (num != 0) return num;
        return dob.compareTo(other.dob);
    }
}
