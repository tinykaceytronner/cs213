/**
 * 
 */
/**
 * @author worms
 *
 */
module project2 {
	requires junit;
}