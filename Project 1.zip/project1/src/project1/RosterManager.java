package project1;

import java.util.Scanner;
import java.util.StringTokenizer;

/**
 * This class gets the input from the user and responds accordingly by calling upon other classes.
 * Uses Scanner and String Tokenizer to get the input.
 * @author Ashika Nadella, Christopher Blanchard
 */
public class RosterManager { // Default constructor
    /**
     * Adds a student to the Roster.
     * Used in the run method.
     * @param fname   the first name of the student to add
     * @param lname   the last name of the student to add
     * @param dob     the date of birth of the student to add
     * @param major   the major of the student to add
     * @param credits the current credits completed of the student to add
     * @param obj     The Roster which will add the student.
     */
    private void A(String fname, String lname, String dob, String major, String credits, Roster obj) {
        major = major.toUpperCase();
        if (!Major.isStringMajor(major)) {
            System.out.println("Major code invalid: " + major);
            return;
        }
        Major majorToAdd = Major.valueOf(major);
        Date dobToAdd = new Date(dob);
        if (!dobToAdd.isValid()) {
            System.out.println("DOB invalid: " + dobToAdd + " not a valid calendar date!");
            return;
        }
        if (dobToAdd.isTodayorFuture() || dobToAdd.birthDateAge() < 16) {
            System.out.println("DOB invalid: " + dobToAdd + " younger than 16 years old.");
            return;
        }
        int creditsCompleted = 0;
        try {
            creditsCompleted = Integer.parseInt(credits);
        } catch (Exception e) {
            System.out.println("Credits completed invalid: not an integer!");
            return;
        }
        if (creditsCompleted < 0) {
            System.out.println("Credits completed invalid: cannot be negative!");
            return;
        }
        Student studentToAdd = new Student(fname, lname, dob, majorToAdd, creditsCompleted);
        if (obj.contains(studentToAdd)) {
            System.out.println(studentToAdd.getProfile() + " is already in the roster.");
            return;
        }
        obj.add(studentToAdd);
        System.out.println(studentToAdd.getProfile() + " added to the roster.");
    }

    /**
     * Tries to remove a student from the Roster.
     * Used in the run method.
     * @param fname the first name of the student
     * @param lname the last name of the student
     * @param dob   the date of birth of the student
     * @param obj   The Roster which will have a student removed.
     */
    private void R(String fname, String lname, String dob, Roster obj) {
        if (obj.studentsInRoster() == 0) {
            System.out.println("Student roster is empty!");
            return;
        }
        boolean g = false;
        Student t = new Student(fname, lname, dob, null, 0);
        for (int i = 0; i < obj.getSize(); i++) {
            if (obj.getRoster()[i] == null) {
                break;
            }
            Student v = (obj.getRoster()[i]);
            g = v.getProfile().equals(t.getProfile());
            if (g == true) {
                obj.remove(obj.getRoster()[i]);
                System.out.println(fname + " " + lname + " " + dob + " removed " +
                        "from the roster.");
                break;
            }
        }
        if (g == false) {
            System.out.println(fname + " " + lname + " " + dob + " is not in the roster.");
        }
    }

    /**
     * Sorts students in the roster by their last names, first names, and dobs.
     * Used in the run method.
     * @param obj The Roster which will be printed.
     */
    private void P(Roster obj) {
        if (obj.studentsInRoster() == 0) {
            System.out.println("Student roster is empty!");
            return;
        }
        System.out.println("* Student roster sorted by last name, first name, DOB **");
        obj.print();
        System.out.println("* end of roster **");
    }

    /**
     * Sorts students in the roster by their standing.
     * Used in the run method.
     * @param obj The Roster which will be printed.
     */
    private void PS(Roster obj) {
        if (obj.studentsInRoster() == 0) {
            System.out.println("Student roster is empty!");
            return;
        }
        System.out.println("* Student roster sorted by standing **");
        obj.printByStanding();
        System.out.println("* end of roster **");
    }

    /**
     * Sorts students in the roster by their schools, and majors.
     * Used in the run method.
     * @param obj The Roster which will be printed.
     */
    private void PC(Roster obj) {
        if (obj.studentsInRoster() == 0) {
            System.out.println("Student roster is empty!");
            return;
        }
        System.out.println("* Student roster sorted by school, major **");
        obj.printBySchoolMajor();
        System.out.println("* end of roster **");
    }

    /**
     * Sorts students in the roster by their last names, first names, and dobs.
     * Then prints out those which are passed in School.
     * Used in the run method.
     * @param obj The Roster which will be printed.
     */
    private void L(String school, Roster obj) {
        if (obj.studentsInRoster() == 0) {
            System.out.println("Student roster is empty!");
            return;
        }
        boolean requestedSchoolInSystem = false;
        for (int i = 0; i < Major.values().length - 1; i++) {
            if (school.equalsIgnoreCase(Major.values()[i].getSchool())) {
                requestedSchoolInSystem = true;
                break;
            }
        }
        if (!requestedSchoolInSystem) {
            System.out.println("School doesn't exist: " + school);
            return;
        } else {
            System.out.println("* Students in " + school + " *");
            obj.printThisSchoolOnly(school);
            System.out.println("* end of list **");
        }
    }

    /**
     * Finds a Student in the given Roster, and changes their Major to the given Major.
     * @param fname Find student first name
     * @param lname Find student last name
     * @param dob   Find student dob
     * @param major Major to change
     * @param obj   Roster
     */
    private void C(String fname, String lname, String dob, String major, Roster obj) {
        major = major.toUpperCase();
        if (!Major.isStringMajor(major)) {
            System.out.println("Major code invalid: " + major);
            return;
        }
        Major newMajor = Major.valueOf(major);
        Profile lookUp = new Profile(fname, lname, dob);
        if (obj.findByProfile(lookUp) == -1) {
            System.out.println(lookUp + " is not in the roster.");
            return;
        }
        if (obj.changeMajor(obj.findByProfile(lookUp), newMajor)) {
            System.out.println(lookUp + " major changed to " + newMajor);
            return;
        }
        System.out.println(lookUp + " already has major " + newMajor);
    }

    /**
     * Gets the input from the user and responds to it by calling upon different methods
     * Responds to "A", "R", "P", "PS", "PC", "L", "C", and "Q"
     * Used in the runProject1 class.
     */
    public void run() {
        System.out.println("Roster Manager running...");
        Roster obj = new Roster();
        Scanner scan = new Scanner(System.in);
        String read = scan.nextLine();
        String input = "";
        System.out.println();
        while (!read.contentEquals("Q")) {
            StringTokenizer a = new StringTokenizer(read, "\s+");
            try {
                input = a.nextToken();
            } catch (Exception e) {
                input = "";
            }
            if (input.contentEquals("A")) {
                A(a.nextToken(), a.nextToken(), a.nextToken(), a.nextToken(), a.nextToken(), obj);
            } else if (input.contentEquals("R")) {
                R(a.nextToken(), a.nextToken(), a.nextToken(), obj);
            } else if (input.contentEquals("P")) {
                P(obj);
            } else if (input.contentEquals("PS")) {
                PS(obj);
            } else if (input.contentEquals("PC")) {
                PC(obj);
            } else if (input.contentEquals("L")) {
                L(a.nextToken(), obj);
            } else if (input.contentEquals("C")) {
                C(a.nextToken(), a.nextToken(), a.nextToken(), a.nextToken(), obj);
            } else if (!input.contentEquals("")) {
                System.out.println(input + " is an invalid command!");
            }
            read = scan.nextLine();
        }
        System.out.println("Roster Manager terminated.");
        scan.close();
    }
}
