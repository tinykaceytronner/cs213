package project1;

/**
 * Major enum class. Major has 2 String values for the corresponding school and code.
 * @author Christopher Blanchard
 */
public enum Major {

    CS("SAS", "01:198"),
    MATH("SAS", "01:640"),
    EE("SOE", "14:332"),
    ITI("SC&I", "04:547"),
    BAIT("RBS", "33:136"),
    UNASSIGNED("", "");

    private final String school;
    private final String code;

    /**
     * Major Constructor. Allows enum to have 2 String values (school and code).
     * @param school String name of the Rutgers school that this Major pertains to.
     * @param code   String name of the Rutgers course code that this Major pertains to.
     */
    private Major(String school, String code) {
        this.school = school;
        this.code = code;
    }

    /**
     * Getter method for grabbing the school of a Major.
     * @return This Major's school.
     */
    public String getSchool() {
        return school;
    }

    /**
     * Getter method for grabbing the code of a Major.
     * @return This Major's code.
     */
    public String getCode() {
        return code;
    }

    /**
     * Method for determining whether or not a random String is equal to a Major that is in the system.
     * @param stringToTest String to compare against all Majors in the system.
     * @return True if stringToTest matches a Major in the system.
     * False if stringToTest does not match a Major in the system.
     */
    public static boolean isStringMajor(String stringToTest) {
        try {
            Major testMajor = Major.valueOf(stringToTest);
            return true;
        } catch (IllegalArgumentException ex) {
            return false;
        }
    }
}
