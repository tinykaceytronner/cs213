package project1;

/**
 * This class creates new students using their profile, major, and credits completed.
 * @author Ashika Nadella
 */
public class Student implements Comparable<Student> {
    private Profile profile;
    private Major major;
    private int creditCompleted;

    /**
     * Getter method that returns the profile of the student to access it in different classes.
     * @return profile which contains last name, first name, and date of birth of the student.
     */
    public Profile getProfile() {
        return profile;
    }

    /**
     * Setter method that sets Student Profile to the passed in Profile.
     * @param newProfile New profile.
     */
    public void setProfile(Profile newProfile) {
        profile = newProfile;
    }

    /**
     * Getter method that returns the major of the student to access it in different classes.
     * @return major which contains major, school, and school code.
     */
    public Major getMajor() {
        return major;
    }

    /**
     * Setter method that sets Student Major to the passed in Major.
     * @param newMajor New major.
     */
    public void setMajor(Major newMajor) {
        major = newMajor;
    }

    /**
     * Getter method that returns the credits completed by the student to access it in different classes.
     * @return credits completed
     */
    public int getCreditsCompleted() {
        return creditCompleted;
    }

    /**
     * Setter method that sets Student Credits Completed to the passed in Credits Completed.
     * @param newCreditsCompleted New Credits Completed.
     */
    public void setCreditsCompleted(int newCreditsCompleted) {
        creditCompleted = newCreditsCompleted;
    }

    /**
     * A student constructor that creates a instance/object of the student class using the student's data.
     * @param fname           student's first name
     * @param lname           student's last name
     * @param date            student's date of birth
     * @param major           student's major
     * @param creditCompleted number of credits completed by the student
     */
    public Student(String fname, String lname, String date, Major major, int creditCompleted) {
        this.profile = new Profile(fname, lname, date);
        this.major = major;
        this.creditCompleted = creditCompleted;
    }

    /**
     * A getter method that returns the standing of the student based on the number of credits completed.
     * It returns invalid if the number of credits is less than 0.
     * @param studentToCheck Pass in the student that will have standing evaluated.
     * @return "Freshman" if [0,30) credits, "Sophomore" if [30,60) credits, "Junior" if [60,90) credits, "Senior" if [90,infinity) credits.
     */
    public String getStanding(Student studentToCheck) {
        if (studentToCheck.creditCompleted < 0) return "Invalid";
        if (studentToCheck.creditCompleted < 30) return "Freshman";
        if (studentToCheck.creditCompleted < 60) return "Sophomore";
        if (studentToCheck.creditCompleted < 90) return "Junior";
        return "Senior";
    }

    /**
     * Compares two student objects' profiles, majors, credits completed to see if they are equal.
     * Overrides the equal method
     * @param obj object that is compared to
     * @return true if both objects are same and false if the object is different or not student type.
     */
    @Override
    public boolean equals(Object obj) {
        if (obj instanceof Student) {
            Student data = (Student) obj;
            boolean profile = data.profile.equals(this.profile);
            boolean major = data.major.equals(this.major);
            boolean credits = data.creditCompleted == this.creditCompleted;
            return profile && major && credits;
        }
        return false;
    }

    /**
     * converts the student's profile, major, and credits completed to a string.
     * Overrides the string method
     * @return string of profile, major, and credits completed.
     */
    @Override
    public String toString() {
        return profile + " " + major + " " + creditCompleted;
    }

    /**
     * compares two students' profiles to sort in lexicographical order
     * Overrides the compareTo method
     * @return 0 if profiles are same, positive number if the other's profile comes before, negative if it comes after.
     */
    @Override
    public int compareTo(Student other) {
        return profile.compareTo(other.profile);
    }

    /**
     * testbed main() with test cases to test the compareTo method
     * tests if last name, first name, and date of birth of students are compared accurately
     */
    public static void main(String[] args) {
        Student[] testCases = new Student[6];
        testCases[0] = new Student("Ashika", "Nadella", "5/23/2002", Major.CS, 25);
        testCases[1] = new Student("Ashik", "Nadella", "5/23/2002", Major.CS, 25);
        testCases[2] = new Student("Ashika", "Nadelli", "5/23/2002", Major.CS, 25);
        testCases[3] = new Student("Ashika", "Nadella", "1/23/2002", Major.CS, 25);
        testCases[4] = new Student("Ashika", "Nadella", "5/24/2002", Major.CS, 25);
        testCases[5] = new Student("Ashika", "Nadella", "5/23/2001", Major.CS, 25);

        System.out.println(testCases[0].compareTo(testCases[1]));
        System.out.println(testCases[0].compareTo(testCases[2]));
        System.out.println(testCases[0].compareTo(testCases[2]));
        System.out.println(testCases[0].compareTo(testCases[4]));
        System.out.println(testCases[0].compareTo(testCases[5]));
    }
}
