package project1;
/**
 * This class mainly adds, removes, finds, and sorts students in the roster.
 * Used Default constructor
 * @author Ashika Nadella
 */
public class Roster {
    private Student[] roster;
    private int size;
    /**
     * Default Constructor to make a new Roster, with default size of 4.
     */
    public Roster() {
        roster = new Student[4];
        size = 4;
    }
    /**
     * A getter method that returns the size of the roster to access it in different classes.
     * @return size the size of the roster.
     */
    public int getSize() {
        return size;
    }
    /**
     * A getter method that returns the roster to access it in different classes.
     * @return roster with all students.
     */
    public Student[] getRoster() {
        return roster;
    }
    public static final int NOT_FOUND = -1; // constant
    /**
     * Finds the student in the roster and returns their index.
     * @param studentToFind search the roster for this student.
     * @return i index of the student, or NOT_FOUND = -1 when the student is not found in the roster.
     */
    private int find(Student studentToFind) {
        for (int i = 0; i < getSize(); i++) {
            if (studentToFind.equals(roster[i])) {
                return i;
            }
        }
        return NOT_FOUND;
    }
    /**
     * Finds the student with Profile in the roster and returns their index.
     * @param profileToFind search the roster for this student.
     * @return i index of the student, or NOT_FOUND = -1 when the student is not found in the roster.
     */
    public int findByProfile(Profile profileToFind) {
        for (int i = 0; i < getSize(); i++) {
            if(roster[i] == null) continue;
            if (profileToFind.equals(roster[i].getProfile())) {
                return i;
            }
        }
        return NOT_FOUND;
    }
    /**
     * Increases the size of the roster if it runs out of space.
     */
    private void grow() {
        int oldSize = size;
        size += 4;
        Student[] newRoster = new Student[size];
        for (int x = 0; x < oldSize; x++) {
            newRoster[x] = roster[x];
        }
        roster = newRoster;
    }
    /**
     * Adds the student to the roster and returns true when it does.
     * @param studentToAdd Student to be added to the roster.
     * @return true when the student is added to the roster.
     */
    public boolean add(Student studentToAdd) {
        for (int i = 0; i < size; i++) {
            if (roster[i] == null) {
                roster[i] = studentToAdd;
                return true;
            }
        }
        int numOfStudents = size;
        grow();
        roster[numOfStudents] = studentToAdd;
        return true;
    }
    /**
     * Removes the student from the roster and returns true when it does it.
     * @param studentToRemove This student will be removed from the roster if they are in it.
     * @return true when the student is removed from the roster.
     */
    public boolean remove(Student studentToRemove) {
        int index = find(studentToRemove);
        size -= 1;
        Student[] newArray = new Student[size];
        for (int i = 0; i < index; i++) {
            newArray[i] = roster[i];
        }
        int x = index + 1;
        while (x <= size) {
            newArray[x - 1] = roster[x];
            if (x + 1 <= size) {
                x++;
            } else {
                break;
            }
        }
        roster = newArray;
        return true;
    }
    /**
     * Checks to see if the student is present in the roster and returns true if the student is present.
     * @param studentToFind The student to search for in the roster.
     * @return true when student is in roster, false when student is not in roster.
     */
    public boolean contains(Student studentToFind) {
        int index = find(studentToFind);
        if (index == NOT_FOUND) return false;
        return true;
    }
    /**
     * Tries to change the major of the student at the roster index that is passed into the method.
     * @param indexOfStudentToEdit Roster index of which to change the major.
     * @param newMajor The desired new major.
     * @return true if major is changed, false if index out of bounds or student already has major.
     */
    public boolean changeMajor(int indexOfStudentToEdit, Major newMajor) {
        if(roster.length <= indexOfStudentToEdit) return false;
        if(roster[indexOfStudentToEdit].getMajor().equals(newMajor)) return false;
        roster[indexOfStudentToEdit].setMajor(newMajor);
        return true;
    }
    /**
     * Count the number of students currently in the roster.
     * Different from Roster.size() because not counting null entries.
     * @return Integer count of students currently in the roster.
     */
    public int studentsInRoster() {
        int count = 0;
        for(int i = 0; i<roster.length-1; i++) {
            if(!(roster[i] == null)) count++;
        }
        return count;
    }
    /**
     * Sorts students in the roster by their last names, first names, and dobs.
     * Uses compareTo method from Student class and prints the new roster.
     */
    public void print() {
        Student temporary;
        for (int x = 0; x < size; x++) {
            for (int y = x + 1; y < size; y++) {
                if (roster[y] == null) {
                    break;
                }
                if (roster[x].compareTo(roster[y]) > 0) {
                    temporary = roster[x];
                    roster[x] = roster[y];
                    roster[y] = temporary;
                }
            }
        }
        for (int i = 0; i < size; i++) {
            if (roster[i] == null) {
                break;
            }
            System.out.println(roster[i].getProfile() + " (" + roster[i].getMajor().getCode() + " "
                    + roster[i].getMajor() + " " + roster[i].getMajor().getSchool() + ") credits completed: "
                    + roster[i].getCreditsCompleted() + " (" + roster[i].getStanding(roster[i]) + ")");
        }
    }
    /**
     * Sorts students in the roster by their last names, first names, and dobs.
     * Uses compareTo method from Student class and prints the roster, only printing Students that are in the passed in School.
     * @param schoolToPrint Roster will only print entries that have this School.
     */
    public void printThisSchoolOnly(String schoolToPrint) {
        Student temporary;
        for (int x = 0; x < size; x++) {
            for (int y = x + 1; y < size; y++) {
                if (roster[y] == null) {
                    break;
                }
                if (roster[x].compareTo(roster[y]) > 0) {
                    temporary = roster[x];
                    roster[x] = roster[y];
                    roster[y] = temporary;
                }
            }
        }
        for (int i = 0; i < size; i++) {
            if (roster[i] == null) {
                break;
            }
            if(roster[i].getMajor().getSchool().equalsIgnoreCase(schoolToPrint)) {
                System.out.println(roster[i].getProfile() + " (" + roster[i].getMajor().getCode() + " "
                        + roster[i].getMajor() + " " + roster[i].getMajor().getSchool() + ") credits completed: "
                        + roster[i].getCreditsCompleted() + " (" + roster[i].getStanding(roster[i]) + ")");
            }
        }
    }
    /**
     * Sorts students in the roster by their schools and then majors.
     * Uses compareTo method and prints the new roster.
     */
    public void printBySchoolMajor() {
        Student temporary;
        for (int x = 0; x < size; x++) {
            for (int y = x + 1; y < size; y++) {
                if (roster[y] == null) {
                    break;
                }
                int num = roster[x].getMajor().getSchool().compareTo(roster[y].getMajor().getSchool());
                if (num == 0) {
                    num = roster[x].getMajor().compareTo(roster[y].getMajor());
                }
                if (num > 0) {
                    temporary = roster[x];
                    roster[x] = roster[y];
                    roster[y] = temporary;
                }
            }
        }
        for (int i = 0; i < size; i++) {
            if (roster[i] == null) {
                break;
            }
            System.out.println(roster[i].getProfile() + " (" + roster[i].getMajor().getCode() + " "
                    + roster[i].getMajor() + " " + roster[i].getMajor().getSchool() + ") credits completed: "
                    + roster[i].getCreditsCompleted() + " (" + roster[i].getStanding(roster[i]) + ")");
        }
    }
    /**
     * Sorts students in the roster by standing in lexicographical order.
     * Uses getStanding method from student class to compare and then prints the new roster.
     */
    public void printByStanding() {
        Student temporary;
        for (int x = 0; x < size; x++) {
            for (int y = x + 1; y < size; y++) {
                if (roster[y] == null) {
                    break;
                }
                if (roster[x].getStanding(roster[x]).compareTo(roster[y].getStanding(roster[y])) > 0) {
                    temporary = roster[x];
                    roster[x] = roster[y];
                    roster[y] = temporary;
                }
            }
        }
        for (int i = 0; i < size; i++) {
            if (roster[i] == null) {
                break;
            }
            System.out.println(roster[i].getProfile() + " (" + roster[i].getMajor().getCode() + " "
                    + roster[i].getMajor() + " " + roster[i].getMajor().getSchool() + ") credits completed: "
                    + roster[i].getCreditsCompleted() + " (" + roster[i].getStanding(roster[i]) + ")");
        }
    }
}
