package project1;
/**
 * This class runs the RosterManager class and displays output accordingly by calling upon other classes.
 * @author Ashika Nadella, Christopher Blanchard
 */
public class RunProject1 {

    /**
     * This method runs the RosterManager's run method.
     */
    public static void main(String[] args) {
        new RosterManager().run();
    }
}

