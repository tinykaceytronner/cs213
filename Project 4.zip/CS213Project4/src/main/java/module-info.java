module cs213.project4.cs213project4 {
    requires javafx.controls;
    requires javafx.fxml;


    opens cs213.project4.cs213project4 to javafx.fxml;
    exports cs213.project4.cs213project4;
    exports Menu;
    opens Menu to javafx.fxml;
}