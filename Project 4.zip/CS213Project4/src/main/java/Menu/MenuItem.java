package Menu;

import javafx.scene.image.Image;

import java.io.File;

public abstract class MenuItem {
    private String itemImagePath;
    private int itemQuantity;
    public String getItemImagePath(){
        return itemImagePath;
    }
    public void setItemImagePath(String itemImagePath){
        this.itemImagePath = itemImagePath;
    }
    public int getItemQuantity(){
        return itemQuantity;
    }
    public void setItemQuantity(int itemQuantity){
        this.itemQuantity = itemQuantity;
    }
    public boolean addToItemQuantity(int toAdd){
        this.itemQuantity += toAdd;
        return true;
    }
    public boolean subFromItemQuantity(int toSub){
        if(this.itemQuantity - toSub < 0) return false;
        this.itemQuantity -= toSub;
        return true;
    }
    public abstract boolean equals(MenuItem other);
    public abstract double itemPrice();
}
