package Menu;

import java.util.ArrayList;
import java.util.List;

public class Coffee extends MenuItem{
    private static final double BASE_PRICE = 1.89;
    private static final double PRICE_PER_SIZE_UP = 0.40;
    private static final double PRICE_PER_ADD_IN = 0.30;
    private CupSize cupSize;
    private List<AddIn> addIns;
    public CupSize getCupSize(){
        return cupSize;
    }
    public void setCupSize(CupSize cupSize){
        this.cupSize = cupSize;
    }
    public List<AddIn> getAddIns(){
        return addIns;
    }
    public void setAddIns(List<AddIn> addIns){
        this.addIns = addIns;
    }
    public Coffee(CupSize cupSize, int itemQuantity){
        this.cupSize = cupSize;
        this.addIns = new ArrayList<AddIn>();
        this.setItemQuantity(itemQuantity);
        this.setItemImagePath(null);
    }
    public Coffee(CupSize cupSize, int itemQuantity, List<AddIn> addIns){

        this.cupSize = cupSize;
        this.addIns = addIns;
        this.setItemQuantity(itemQuantity);
        this.setItemImagePath(null);
    }
    public boolean addToAddIns(AddIn toAdd){
        if(addIns.contains(toAdd)) return false;
        addIns.add(toAdd);
        return true;
    }
    public boolean removeFromAddIns(AddIn toRemove){
        if(!addIns.contains(toRemove)) return false;
        addIns.remove(toRemove);
        return true;
    }

    @Override
    public boolean equals(MenuItem other) {
        if(!getClass().equals(other.getClass())) return false;
        if(other.getItemQuantity() != getItemQuantity()) return false;
        if(((Coffee) other).getCupSize() != getCupSize()) return false;
        for(int i = 0; i < getAddIns().size(); i++){
            if(((Coffee) other).getAddIns().get(i) != this.addIns.get(i)) return false;
        }
        return true;
    }

    @Override
    public double itemPrice() {
        return getItemQuantity() *
                (BASE_PRICE + (cupSize.ordinal() * PRICE_PER_SIZE_UP) + (addIns.size() * PRICE_PER_ADD_IN));
    }
    @Override
    public String toString() {
        return cupSize + addInsDisplay() + " " + getClass().getSimpleName()
                + " " + getItemQuantity() + "x";
    }
    public String addInsDisplay(){
        if(addIns == null) return "";
        if(addIns.size() == 0) return "";
        String output = "";
        for(int i = 0; i < addIns.size(); i++){
            if(!output.contains(addIns.get(i).toString()))output += " " + addIns.get(i);
        }
        return output;
    }
}
