package Menu;

public class Yeast extends Donut{
    public Yeast(Flavor flavor, int itemQuantity){
        super(flavor,itemQuantity);
        setItemImagePath(flavor.getDonutImagePath());
    }

    @Override
    public boolean equals(MenuItem other) {
        if(!getClass().equals(other.getClass())) return false;
        if(((Yeast) other).getFlavor() != getFlavor()) return false;
        if(other.getItemQuantity() != getItemQuantity()) return false;
        return true;
    }

    @Override
    public double itemPrice() {
        return getItemQuantity() * PRICE_YEAST_DONUT;
    }
    @Override
    public String toString() {
        return getFlavor().toString() + " Yeast Donut " + getItemQuantity() + "x";
    }
}
