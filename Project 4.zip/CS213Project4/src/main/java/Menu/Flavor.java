package Menu;
import java.io.File;

public enum Flavor {
    Vanilla_Frosted("Vanilla Frosted",false),
    Chocolate_Frosted("Chocolate Frosted",false),
    Strawberry_Frosted("Strawberry Frosted",false),
    Jelly("Jelly",true),
    Plain_Glazed("Glazed",true),
    Chocolate_Glazed("Glazed Chocolate",true),
    Strawberry_Banana("Strawberry Banana",false),
    Gutter_Sludge("Gutter Sludge",false),
    Lemon_Lime("Lemon Lime",false);
    private final String simpleName;
    private final String donutImagePath;
    private final String holeImagePath;

    public String toString(){
        return simpleName;
    }
    public String getDonutImagePath(){
        return donutImagePath;
    }
    public String getHoleImagePath(){
        return holeImagePath;
    }
    private Flavor(String simpleName, boolean hasHole){
        this.simpleName = simpleName;
        this.donutImagePath = "src/main/resources/RUCafe_Images/Donut_" + this.name() + ".png";
        this.holeImagePath = hasHole ? "src/main/resources/RUCafe_Images/Hole_" + this.name() + ".png" : null;
    }
}
