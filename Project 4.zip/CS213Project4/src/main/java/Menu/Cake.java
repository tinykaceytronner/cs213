package Menu;

public class Cake extends Donut{
    public Cake(Flavor flavor, int itemQuantity) {
        super(flavor, itemQuantity);
        setItemImagePath(flavor.getDonutImagePath());
    }
    @Override
    public double itemPrice() {
        return getItemQuantity() * PRICE_CAKE_DONUT;
    }
    @Override
    public boolean equals(MenuItem other) {
        if(!getClass().equals(other.getClass())) return false;
        if(((Cake) other).getFlavor() != getFlavor()) return false;
        if(other.getItemQuantity() != getItemQuantity()) return false;
        return true;
    }
    @Override
    public String toString() {
        return getFlavor().toString() + " Cake Donut " + getItemQuantity() + "x";
    }
}
