package Menu;

import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.List;

public class Order {
    public static final double NJ_SALES_TAX = 0.06625;
    private int orderNumber;
    private List<MenuItem> orderItems;
    public int getOrderNumber(){
        return orderNumber;
    }
    public void setOrderNumber(int orderNumber){
        this.orderNumber = orderNumber;
    }
    public List<MenuItem> getOrderItems(){
        return orderItems;
    }
    public void setOrderItems(List<MenuItem> orderItems){
        this.orderItems = orderItems;
    }
    public Order(){
        this.orderNumber = -1;
        this.orderItems = new ArrayList<MenuItem>();
    }
    public Order(List<MenuItem> orderItems){
        this.orderNumber = -1;
        this.orderItems = orderItems;
    }
    public Order(int orderNumber){
        this.orderNumber = orderNumber;
        this.orderItems = new ArrayList<MenuItem>();
    }
    public Order(int orderNumber, List<MenuItem> orderItems){
        this.orderNumber = orderNumber;
        this.orderItems = orderItems;
    }
    public boolean hasItem(MenuItem toCheck){
        for(int i = 0; i < orderItems.size(); i++){
            if(toCheck.equals(orderItems.get(i))) return true;
        }
        return false;
    }
    public boolean addItem(MenuItem toAdd){
        if(orderItems == null) return false;
        orderItems.add(toAdd);
        return true;
    }
    public boolean removeItem(MenuItem toRemove){
        if(orderItems == null) return false;
        if(!hasItem(toRemove)) return false;
        for(int i = 0; i < orderItems.size(); i++){
            if(toRemove.equals(orderItems.get(i))){
                orderItems.remove(i);
                return true;
            }
        }
        return false;
    }
    public boolean clearAllItems(){
        if(orderItems == null) return true;
        orderItems = new ArrayList<MenuItem>();
        return true;
    }
    public double subTotal(){
        if(orderItems == null) return 0;
        if(orderItems.size() == 0) return 0;
        double subTotal = 0;
        for(int i = 0; i < orderItems.size(); i++){
            subTotal += orderItems.get(i).itemPrice();
        }
        return subTotal;
    }
    public double taxTotal(){
        return subTotal() * NJ_SALES_TAX;
    }
    public double orderTotal(){
        return subTotal() + taxTotal();
    }
    public static String MoneyFormat(double money){
        NumberFormat formatter = NumberFormat.getCurrencyInstance();
        String moneyString = formatter.format(money);
        return moneyString;
    }
    public String toString(){
        if(orderItems == null) return "";
        if(orderItems.size() == 0) return "";
        String output = "Order #" + orderNumber + "\n";
        for(int i = 0; i < orderItems.size(); i++){
            output += "- " + orderItems.get(i).toString() + "\n";
        }
        return output;
    }
}
