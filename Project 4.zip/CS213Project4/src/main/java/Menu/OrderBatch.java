package Menu;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class OrderBatch {
    private int orderBatchNumber;
    private int newOrderCount;
    private List<Order> orderList;
    public int getOrderBatchNumber(){
        return orderBatchNumber;
    }
    public void setOrderBatchNumber(int orderBatchNumber){
        this.orderBatchNumber = orderBatchNumber;
    }
    public int getNewOrderCount(){
        return newOrderCount;
    }
    public void setNewOrderCount(int newOrderCount){
        this.newOrderCount = newOrderCount;
    }
    public List<Order> getOrderList(){
        return orderList;
    }
    public void setOrderList(List<Order> orderList){
        this.orderList = orderList;
    }
    public OrderBatch(){
        newOrderCount = 0;
        orderList = new ArrayList<Order>();
    }
    public boolean addOrder(Order toAdd){
        if(orderList == null) return false;
        newOrderCount++;
        toAdd.setOrderNumber(newOrderCount);
        orderList.add(toAdd);
        return true;
    }
    public boolean removeOrder(Order toRemove){
        if(orderList == null) return false;
        if(orderList.size() == 0) return false;
        if(!orderList.contains(toRemove)) return false;
        orderList.remove(toRemove);
        return true;
    }
    public boolean resetOrderBatch(){
        if(orderList == null) return false;
        orderList = new ArrayList<Order>();
        newOrderCount = 0;
        orderBatchNumber++;
        return true;
    }
    public double subTotal(){
        if(orderList == null) return 0;
        if(orderList.size() == 0) return 0;
        double subTotal = 0;
        for(int i = 0; i < orderList.size(); i++){
            subTotal += orderList.get(i).subTotal();
        }
        return subTotal;
    }
    public double taxTotal(){
        return subTotal() * Order.NJ_SALES_TAX;
    }
    public double orderListTotal(){
        return subTotal() + taxTotal();
    }
    public String toString(){
        if(orderList == null) return "";
        if(orderList.size() == 0) return "";
        String output = "Order batch:\n";
        for(int i = 0; i < orderList.size(); i++){
            output += orderList.get(i).toString() + "\n";
        }
        return output;
    }
    public void SaveBatchToTextFile(String s) throws FileNotFoundException {
        try {
            File myObj = new File("orderbatch_" + orderBatchNumber + ".txt");
            if (myObj.createNewFile());
        } catch (IOException e) {
            e.printStackTrace();
        }
        try {
            FileWriter myWriter = new FileWriter("orderbatch_" + orderBatchNumber + ".txt");
            myWriter.write(s);
            myWriter.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
