package Menu;

public abstract class Donut extends MenuItem {
    public static final double PRICE_YEAST_DONUT = 1.59;
    public static final double PRICE_CAKE_DONUT = 1.79;
    public static final double PRICE_HOLE_DONUT = 0.39;
    private Flavor flavor;
    public Flavor getFlavor(){
        return flavor;
    }
    public void setFlavor(Flavor flavor){
        this.flavor = flavor;
    }
    public Donut(Flavor flavor, int itemQuantity){
        setFlavor(flavor);
        setItemQuantity(itemQuantity);
    }
}
