package Menu;

public enum CupSize {
    Short,
    Tall,
    Grande,
    Venti;
}
