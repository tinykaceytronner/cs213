package Menu;

public enum AddIn {
    Sweet_Cream("Sweet Cream"),
    French_Vanilla("French Vanilla"),
    Irish_Cream("Irish Cream"),
    Caramel("Caramel"),
    Mocha("Mocha");
    private final String name;
    private AddIn(String name){
        this.name = name;
    }
    public String toString(){
        return name;
    }
}
