package Menu;

public class Hole extends Donut {
    public Hole(Flavor flavor, int itemQuantity) {
        super(flavor, itemQuantity);
        setItemImagePath(flavor.getHoleImagePath());
    }
    @Override
    public double itemPrice() {
        return getItemQuantity() * PRICE_HOLE_DONUT;
    }

    @Override
    public boolean equals(MenuItem other) {
        if(!getClass().equals(other.getClass())) return false;
        if(((Hole) other).getFlavor() != getFlavor()) return false;
        if(other.getItemQuantity() != getItemQuantity()) return false;
        return true;
    }
    @Override
    public String toString() {
        return getFlavor().toString() + " Donut Holes " + getItemQuantity() + "x";
    }
}
