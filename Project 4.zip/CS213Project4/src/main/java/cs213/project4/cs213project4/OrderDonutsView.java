package cs213.project4.cs213project4;

import Menu.*;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.net.URL;
import java.util.ResourceBundle;

public class OrderDonutsView implements Initializable {
    RUCafe_Controller_Data data = RUCafe_Controller_Data.getInstance();
    private static final int MAX_DONUTS_DISPLAYED = 6;
    @FXML
    private Button b_main;
    @FXML
    private Button b_orderCoffee;
    @FXML
    private Button b_currentOrder;
    @FXML
    private Button b_allOrders;
    @FXML
    void OnMainPressed(ActionEvent event) throws Exception {
        SceneSetter.setToScene(b_main,"main-view.fxml");
    }
    @FXML
    void OnOrderCoffeePressed(ActionEvent event) throws Exception {
        SceneSetter.setToScene(b_orderCoffee,"order-coffee-view.fxml");
    }
    @FXML
    void OnCurrentOrderPressed(ActionEvent event) throws Exception {
        SceneSetter.setToScene(b_currentOrder,"current-order-view.fxml");
    }
    @FXML
    void OnAllOrdersPressed(ActionEvent event) throws Exception {
        SceneSetter.setToScene(b_allOrders,"all-order-view.fxml");
    }

    private String[] Donut_Types = {"Yeast","Cake","Holes"};
    private Flavor[] Yeast_flavors =
            {Flavor.Strawberry_Frosted,Flavor.Vanilla_Frosted,Flavor.Chocolate_Frosted,
            Flavor.Plain_Glazed,Flavor.Chocolate_Glazed,Flavor.Jelly};
    private Flavor[] Cake_flavors = {Flavor.Strawberry_Banana,Flavor.Lemon_Lime,Flavor.Gutter_Sludge};
    private Flavor[] Holes_flavors = {Flavor.Chocolate_Glazed,Flavor.Plain_Glazed,Flavor.Jelly};
    @FXML
    private ComboBox Donut_ComboBox;
    @FXML
    private ListView Donut_ListView;
    @FXML
    private VBox Donut_VBox_0;
    @FXML
    private VBox Donut_VBox_1;
    @FXML
    private VBox Donut_VBox_2;
    @FXML
    private VBox Donut_VBox_3;
    @FXML
    private VBox Donut_VBox_4;
    @FXML
    private VBox Donut_VBox_5;
    @FXML
    private ImageView Donut_Image_0;
    @FXML
    private ImageView Donut_Image_1;
    @FXML
    private ImageView Donut_Image_2;
    @FXML
    private ImageView Donut_Image_3;
    @FXML
    private ImageView Donut_Image_4;
    @FXML
    private ImageView Donut_Image_5;
    @FXML
    private ImageView Donut_Image2_0;
    @FXML
    private ImageView Donut_Image2_1;
    @FXML
    private ImageView Donut_Image2_2;
    @FXML
    private ImageView Donut_Image2_3;
    @FXML
    private ImageView Donut_Image2_4;
    @FXML
    private ImageView Donut_Image2_5;
    @FXML
    private Text Donut_Text_0;
    @FXML
    private Text Donut_Text_1;
    @FXML
    private Text Donut_Text_2;
    @FXML
    private Text Donut_Text_3;
    @FXML
    private Text Donut_Text_4;
    @FXML
    private Text Donut_Text_5;
    @FXML
    void OnDonutTypeSelected() throws FileNotFoundException {
        UpdateDonutsDisplay();
        UpdateDonutListView();
    }
    public void UpdateDonutListView(){
        switch(Donut_ComboBox.getValue().toString()){
            case "Yeast":
                Donut_ListView.getItems().setAll(Yeast_flavors);
                break;
            case "Cake":
                Donut_ListView.getItems().setAll(Cake_flavors);
                break;
            case "Holes":
                Donut_ListView.getItems().setAll(Holes_flavors);
                break;
        }
    }
    public void UpdateDonutsDisplay() throws FileNotFoundException {
        Flavor[] donutsToDisplay = new Flavor[MAX_DONUTS_DISPLAYED];
        switch(Donut_ComboBox.getValue().toString()){
            case "Yeast":
                for(int i = 0; i < MAX_DONUTS_DISPLAYED; i++){
                    if(i < Yeast_flavors.length) {
                        donutsToDisplay[i] = Yeast_flavors[i];
                        Donut_Texts[i].setText(donutsToDisplay[i].toString());
                        Donut_Images[i].setImage(new Image(new FileInputStream(donutsToDisplay[i].getDonutImagePath())));
                    }
                    else donutsToDisplay[i] = null;
                    Donut_VBoxes[i].setVisible(donutsToDisplay[i] != null);
                }
                break;
            case "Cake":
                for(int i = 0; i < MAX_DONUTS_DISPLAYED; i++){
                    if(i < Cake_flavors.length) {
                        donutsToDisplay[i] = Cake_flavors[i];
                        Donut_Texts[i].setText(donutsToDisplay[i].toString());
                        Donut_Images[i].setImage(new Image(new FileInputStream(donutsToDisplay[i].getDonutImagePath())));
                    }
                    else donutsToDisplay[i] = null;
                    Donut_VBoxes[i].setVisible(donutsToDisplay[i] != null);
                }
                break;
            case "Holes":
                for(int i = 0; i < MAX_DONUTS_DISPLAYED; i++){
                    if(i < Holes_flavors.length) {
                        donutsToDisplay[i] = Holes_flavors[i];
                        Donut_Texts[i].setText(donutsToDisplay[i].toString());
                        Donut_Images[i].setImage(new Image(new FileInputStream(donutsToDisplay[i].getHoleImagePath())));
                    }
                    else donutsToDisplay[i] = null;
                    Donut_VBoxes[i].setVisible(donutsToDisplay[i] != null);
                }
                break;
        }
    }
    @FXML
    VBox[] Donut_VBoxes;
    @FXML
    ImageView[] Donut_Images;
    @FXML
    ImageView[] Donut_Images2;
    @FXML
    Text[] Donut_Texts;
    private Image ImageFromFileString(String s){
        Image image;
        try{
            image = new Image(new FileInputStream(s));
        }catch(Exception e){
            return null;
        }
        return image;
    }
    @FXML
    public void OnListViewItemSelected(){
    }
    public void Highlight(int index){
        for(int i = 0; i < MAX_DONUTS_DISPLAYED; i++){
            if(i == index) Donut_Images2[i].setImage(ImageFromFileString("src/main/resources/RUCafe_Images/Bg_Donut2.png"));
            else Donut_Images2[i].setImage(ImageFromFileString("src/main/resources/RUCafe_Images/Bg_Donut.png"));
        }
    }
    public Text t_Quantity;
    public int quantity;
    public void UpdateQuantityDisplay(){
        t_Quantity.setText(quantity + "x");
    }
    @FXML
    public void OnDecrementPressed(){
        if(quantity == 0) return;
        quantity--;
        UpdateQuantityDisplay();
    }
    @FXML
    public void OnIncrementPressed(){
        quantity++;
        UpdateQuantityDisplay();
    }
    @FXML
    public void OnAddToOrderPressed(){
        if(quantity == 0) return;
        Donut donutToAdd = null;  //to change
        if(Donut_ListView.getSelectionModel().getSelectedItem() == null) return;
        Flavor flavorToAdd = (Flavor) Donut_ListView.getSelectionModel().getSelectedItem();
        switch(Donut_ComboBox.getValue().toString()){
            case "Yeast":
                donutToAdd = new Yeast(flavorToAdd,quantity);
                break;
            case "Cake":
                donutToAdd = new Cake(flavorToAdd,quantity);
                break;
            case "Holes":
                donutToAdd = new Hole(flavorToAdd,quantity);
                break;
        }
        data.getCurrentOrder().addItem(donutToAdd);
        UpdateOrderBasketDisplay();
    }
    @FXML
    public void OnRemoveFromOrderPressed(){
        Donut donutToRemove = null;
        if(Donut_ListView.getSelectionModel().getSelectedItem() == null) return;
        Flavor flavorToAdd = (Flavor) Donut_ListView.getSelectionModel().getSelectedItem();
        switch(Donut_ComboBox.getValue().toString()){
            case "Yeast":
                donutToRemove = new Yeast(flavorToAdd,quantity);
                break;
            case "Cake":
                donutToRemove = new Cake(flavorToAdd,quantity);
                break;
            case "Holes":
                donutToRemove = new Hole(flavorToAdd,quantity);
                break;
        }
        if(data.getCurrentOrder().removeItem(donutToRemove)) UpdateOrderBasketDisplay();
    }
    @FXML
    public HBox Donut_HBox_RemoveOrClear;
    @FXML
    public void OnClearOrderPressed(){
        areYouSure.setVisible(true);
        Donut_HBox_RemoveOrClear.setVisible(false);
    }
    @FXML
    public HBox areYouSure;
    @FXML
    public void OnConfirmClearPressed(){
        areYouSure.setVisible(false);
        Donut_HBox_RemoveOrClear.setVisible(true);
        data.getCurrentOrder().clearAllItems();
        UpdateOrderBasketDisplay();
    }
    @FXML
    public void OnDenyClearPressed(){
        areYouSure.setVisible(false);
        Donut_HBox_RemoveOrClear.setVisible(true);
    }
    @FXML
    public TextArea Donut_OrderBasket_TextArea;
    @FXML
    public TextArea Donut_OrderBasket_Subtotal;
    @FXML
    public void UpdateOrderBasketDisplay(){
        Donut_OrderBasket_TextArea.setText(data.getCurrentOrder().toString());
        Donut_OrderBasket_Subtotal.setText("Subtotal: " + data.getCurrentOrder().MoneyFormat(data.getCurrentOrder().subTotal()));
    }

    @Override
    public void initialize(URL fxmlFileLocation, ResourceBundle resources){
        quantity = 0;
        UpdateQuantityDisplay();
        Donut_Texts = new Text[]{Donut_Text_0, Donut_Text_1, Donut_Text_2, Donut_Text_3, Donut_Text_4, Donut_Text_5};
        Donut_Images = new ImageView[]{Donut_Image_0, Donut_Image_1, Donut_Image_2, Donut_Image_3, Donut_Image_4, Donut_Image_5};
        Donut_Images2 = new ImageView[]{Donut_Image2_0, Donut_Image2_1, Donut_Image2_2, Donut_Image2_3, Donut_Image2_4, Donut_Image2_5};
        Donut_VBoxes = new VBox[]{Donut_VBox_0, Donut_VBox_1, Donut_VBox_2, Donut_VBox_3, Donut_VBox_4, Donut_VBox_5};
        Donut_ComboBox.getItems().setAll(Donut_Types);
        Donut_ComboBox.setValue(Donut_Types[0]);
        try {
            UpdateDonutsDisplay();
            UpdateDonutListView();
        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        }

        Donut_ListView.getSelectionModel().selectedItemProperty().addListener(new ChangeListener<Flavor>() {
            @Override
            public void changed(ObservableValue<? extends Flavor> observableValue, Flavor flavor, Flavor t1) {
                Highlight(Donut_ListView.getSelectionModel().getSelectedIndex());
            }
        });
        UpdateOrderBasketDisplay();
    }
}
