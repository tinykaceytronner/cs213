package cs213.project4.cs213project4;

import Menu.Flavor;
import Menu.MenuItem;
import Menu.Order;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;
import javafx.scene.control.TextArea;
import javafx.scene.image.ImageView;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;

import java.io.FileNotFoundException;
import java.net.URL;
import java.util.ResourceBundle;

public class CurrentOrderView implements Initializable {
    RUCafe_Controller_Data data = RUCafe_Controller_Data.getInstance();
    @FXML
    private Button b_main;
    @FXML
    private Button b_orderDonuts;
    @FXML
    private Button b_orderCoffee;
    @FXML
    private Button b_allOrders;
    @FXML
    private TextArea TOTALDISPLAY;
    @FXML
    private TextArea SELECTEDITEM;
    @FXML
    private Button increment;
    @FXML
    private Button decrement;
    @FXML
    private TextArea a;

    @FXML
    private void OnRemoveSelectedPressed(){
        if(selectedIndex == -1) return;
        if(data.getCurrentOrder().getOrderItems().size()==0)return;
        data.getCurrentOrder().removeItem(data.getCurrentOrder().getOrderItems().get(selectedIndex));
        if(data.getCurrentOrder().getOrderItems().size()==0)selectedIndex = -1;
        else selectedIndex = 0;
        UpdateSelectedItemView();
        UpdateThisOrderView();
        UpdateTotalView();
    }
    @FXML
    private void OnPlaceOrderPressed(){
        if(data.getCurrentOrder().getOrderItems().size() == 0) return;
        data.getOrderBatch().addOrder(data.getCurrentOrder());
        data.setCurrentOrder(new Order());
        selectedIndex = -1;
        UpdateThisOrderView();
        UpdateTotalView();
        UpdateSelectedItemView();
    }
    @FXML
    void OnMainPressed(ActionEvent event) throws Exception {
        SceneSetter.setToScene(b_main,"main-view.fxml");
    }
    @FXML
    void OnOrderDonutsPressed(ActionEvent event) throws Exception {
        SceneSetter.setToScene(b_orderDonuts,"order-donuts-view.fxml");
    }
    @FXML
    void OnOrderCoffeePressed(ActionEvent event) throws Exception {
        SceneSetter.setToScene(b_orderCoffee,"order-coffee-view.fxml");
    }
    @FXML
    void OnAllOrdersPressed(ActionEvent event) throws Exception {
        SceneSetter.setToScene(b_allOrders,"all-order-view.fxml");
    }
    private void UpdateThisOrderView(){
        String output = "";
        for(int i = 0; i< data.getCurrentOrder().getOrderItems().size();i++){
            output += data.getCurrentOrder().getOrderItems().get(i).toString()
                    + " " + Order.MoneyFormat(data.getCurrentOrder().getOrderItems().get(i).itemPrice()) + "\n";
        }
        if(a != null)a.setText(output);
        UpdateTotalView();
    }
    private void UpdateTotalView(){
        TOTALDISPLAY.setText(
                Order.MoneyFormat(data.getCurrentOrder().subTotal())
                        + " + (" + Order.MoneyFormat(data.getCurrentOrder().taxTotal())
                        + ") = " + Order.MoneyFormat(data.getCurrentOrder().orderTotal()));
    }
    private void UpdateSelectedItemView(){
        if(selectedIndex == -1){
            SELECTEDITEM.setText("");
            return;
        }
        SELECTEDITEM.setText(data.getCurrentOrder().getOrderItems().get(selectedIndex)+"");
        UpdateTotalView();
    }
    @FXML
    private void OnDecrementPressed(){
        if(selectedIndex == 0) return;
        if(data.getCurrentOrder().getOrderItems().size() == 0) {
            selectedIndex = -1;
            UpdateSelectedItemView();
            return;
        }
        selectedIndex--;
        if(data.getCurrentOrder().getOrderItems().size() < selectedIndex)
            selectedIndex = data.getCurrentOrder().getOrderItems().size()-1;
        UpdateSelectedItemView();
    }
    @FXML
    private void OnIncrementPressed(){
        if(data.getCurrentOrder().getOrderItems().size() == 0) {
            selectedIndex = -1;
            UpdateSelectedItemView();
            return;
        }
        if(selectedIndex == data.getCurrentOrder().getOrderItems().size()-1) {
            UpdateSelectedItemView();
            return;
        }
        selectedIndex++;
        UpdateSelectedItemView();
    }
    private int selectedIndex;
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle){
        if(data.getCurrentOrder().getOrderItems().size()==0) selectedIndex = -1;
        else selectedIndex = 0;
        UpdateThisOrderView();
        UpdateSelectedItemView();
    }
}
