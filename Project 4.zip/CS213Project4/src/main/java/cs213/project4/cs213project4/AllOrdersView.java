package cs213.project4.cs213project4;

import Menu.Order;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.scene.image.ImageView;

import java.io.FileNotFoundException;
import java.net.URL;
import java.util.ResourceBundle;

public class AllOrdersView implements Initializable {
    RUCafe_Controller_Data data = RUCafe_Controller_Data.getInstance();
    public void setUserData(RUCafe_Controller_Data data){
        this.data = data;
    }
    public RUCafe_Controller_Data getUserData(){
        return data;
    }
    @FXML
    private Button b_main;
    @FXML
    private Button b_orderDonuts;
    @FXML
    private Button b_orderCoffee;
    @FXML
    private Button b_currentOrder;
    @FXML
    private ImageView i_main;
    @FXML
    private ImageView i_orderDonuts;
    @FXML
    private ImageView i_orderCoffee;
    @FXML
    private ImageView i_currentOrder;
    @FXML
    void OnRemoveOrderPressed(){
        if(selectedIndex == -1) return;
        if(data.getOrderBatch().getOrderList().size() ==0)return;
        data.getOrderBatch().removeOrder(data.getOrderBatch().getOrderList().get(selectedIndex));
        if(data.getOrderBatch().getOrderList().size()==0)selectedIndex = -1;
        else selectedIndex = 0;
        UpdateMenus();
    }
    @FXML
    void OnIncPressed(){
        if(data.getOrderBatch().getOrderList().size() == 0) {
            selectedIndex = -1;
            UpdateMenus();
            return;
        }
        if(selectedIndex == data.getOrderBatch().getOrderList().size()-1) {
            UpdateMenus();
            return;
        }
        selectedIndex++;
        UpdateMenus();
    }
    @FXML
    void OnDecPressed(){
        if(selectedIndex == 0) return;
        if(data.getOrderBatch().getOrderList().size() == 0) {
            selectedIndex = -1;
            UpdateMenus();
            return;
        }
        selectedIndex--;
        if(data.getOrderBatch().getOrderList().size() < selectedIndex)
            selectedIndex =data.getOrderBatch().getOrderList().size()-1;
        UpdateMenus();
    }
    @FXML
    void OnExpPressed() throws FileNotFoundException {
        data.getOrderBatch().SaveBatchToTextFile(data.getOrderBatch().toString());
    }
    @FXML
    private TextArea dispList;
    @FXML
    private TextArea dispTotal;
    @FXML
    private TextArea dispSelected;
    private int selectedIndex;
    private void UpdateMenus(){

        dispList.setText(data.getOrderBatch().toString());
        String dollars = "";
        for(int i = 0; i< data.getOrderBatch().getOrderList().size();i++){
            dollars += data.getOrderBatch().getOrderList().get(i).toString()
                    + " " + Order.MoneyFormat(data.getOrderBatch().getOrderList().get(i).orderTotal()) + "\n";
        }
        dispTotal.setText(dollars);
        if(selectedIndex == -1) {
            dispSelected.setText("");
            return;
        }
        if(selectedIndex > data.getOrderBatch().getOrderList().size()-1) {
            dispSelected.setText("");
            return;
        }
        dispSelected.setText(data.getOrderBatch().getOrderList().get(selectedIndex) + " " + Order.MoneyFormat(data.getOrderBatch().getOrderList().get(selectedIndex).orderTotal()));
    }
    @FXML
    void OnMainPressed(ActionEvent event) throws Exception {
        SceneSetter.setToScene(b_main,"main-view.fxml");
    }
    @FXML
    void OnOrderDonutsPressed(ActionEvent event) throws Exception {
        SceneSetter.setToScene(b_orderDonuts,"order-donuts-view.fxml");
    }
    @FXML
    void OnOrderCoffeePressed(ActionEvent event) throws Exception {
        SceneSetter.setToScene(b_orderCoffee,"order-coffee-view.fxml");
    }
    @FXML
    void OnCurrentOrderPressed(ActionEvent event) throws Exception {
        SceneSetter.setToScene(b_currentOrder,"current-order-view.fxml");
    }
    @FXML
    private ImageView i_background;

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        if(data.getOrderBatch().getOrderList().size()==0) selectedIndex = -1;
        else selectedIndex = 0;
        UpdateMenus();
    }
}
