package cs213.project4.cs213project4;

import Menu.Order;
import Menu.OrderBatch;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;
public class SceneSetter {
    public static final int windowWidth = 800;
    public static final int windowHeight = 600;
    public static void setToScene(Button button, String fxml_path) throws Exception {
        Parent view = FXMLLoader.load(RUCafeGUI.class.getResource(fxml_path));
        Scene oldScene = button.getScene();
        Stage _stage = (Stage)oldScene.getWindow();
        Scene newScene = new Scene(view,windowWidth,windowHeight);
        _stage.setScene(newScene);
    }
}
