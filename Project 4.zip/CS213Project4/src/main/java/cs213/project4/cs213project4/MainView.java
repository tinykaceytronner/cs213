package cs213.project4.cs213project4;

import Menu.Coffee;
import Menu.CupSize;
import Menu.Order;
import Menu.OrderBatch;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.image.ImageView;

import java.net.URL;
import java.util.ResourceBundle;

public class MainView implements Initializable {
    RUCafe_Controller_Data data = RUCafe_Controller_Data.getInstance();
    @FXML
    private Button b_orderDonuts;
    @FXML
    private Button b_orderCoffee;
    @FXML
    private Button b_currentOrder;
    @FXML
    private Button b_allOrders;
    @FXML
    private ImageView i_orderDonuts;
    @FXML
    private ImageView i_orderCoffee;
    @FXML
    private ImageView i_currentOrder;
    @FXML
    private ImageView i_allOrders;
    @FXML
    void OnOrderDonutsPressed(ActionEvent event) throws Exception {
        SceneSetter.setToScene(b_orderDonuts,"order-donuts-view.fxml");

    }
    @FXML
    void OnOrderCoffeePressed(ActionEvent event) throws Exception {
        SceneSetter.setToScene(b_orderCoffee,"order-coffee-view.fxml");
    }
    @FXML
    void OnCurrentOrderPressed(ActionEvent event) throws Exception {
        SceneSetter.setToScene(b_currentOrder,"current-order-view.fxml");
    }
    @FXML
    void OnAllOrdersPressed(ActionEvent event) throws Exception {
        SceneSetter.setToScene(b_allOrders,"all-order-view.fxml");
    }
    @FXML
    private ImageView i_background;

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
    }
}
