package cs213.project4.cs213project4;

import Menu.Order;
import Menu.OrderBatch;

public class RUCafe_Controller_Data {
    public static final RUCafe_Controller_Data instance = new RUCafe_Controller_Data();
    public RUCafe_Controller_Data(){}
    public void initialize(){
        orderTally = 0;
        this.orderBatch = new OrderBatch();
        this.currentOrder = new Order(orderTally);
    }
    public void setOrderTally(int orderTally){
        this.orderTally = orderTally;
    }
    private OrderBatch orderBatch;
    private Order currentOrder;
    private int orderTally;
    public static RUCafe_Controller_Data getInstance(){
        return instance;
    }
    public OrderBatch getOrderBatch(){
        return orderBatch;
    }
    public void setOrderBatch(OrderBatch orderBatch){
        this.orderBatch = orderBatch;
    }
    public Order getCurrentOrder(){
        return currentOrder;
    }
    public void setCurrentOrder(Order currentOrder){
        this.currentOrder = currentOrder;
    }

}
