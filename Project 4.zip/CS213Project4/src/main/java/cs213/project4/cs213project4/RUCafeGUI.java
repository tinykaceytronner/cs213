package cs213.project4.cs213project4;

import java.io.IOException;

import Menu.Coffee;
import Menu.CupSize;
import Menu.Order;
import Menu.OrderBatch;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class RUCafeGUI extends Application {
    @Override
    public void start(Stage mainStage) throws IOException {
        RUCafe_Controller_Data.getInstance().initialize();
        FXMLLoader view = new FXMLLoader(RUCafeGUI.class.getResource("main-view.fxml"));
        Scene _scene = new Scene(view.load(), SceneSetter.windowWidth, SceneSetter.windowHeight);
        mainStage.setScene(_scene);
        mainStage.setResizable(false);
        mainStage.setTitle("RUCafe Order Manager");
        mainStage.show();
    }

    public static void main(String[] args) {
        launch();
    }
}