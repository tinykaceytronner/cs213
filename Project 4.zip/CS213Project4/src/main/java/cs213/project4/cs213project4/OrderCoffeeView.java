package cs213.project4.cs213project4;

import Menu.*;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.net.URL;
import java.util.ResourceBundle;


public class OrderCoffeeView implements Initializable {
    RUCafe_Controller_Data data = RUCafe_Controller_Data.getInstance();
    private static final int MAX_COFFEE_ADD_INS = 5;
    @FXML
    private Button b_main;
    @FXML
    private Button b_orderDonuts;
    @FXML
    private Button b_currentOrder;
    @FXML
    private Button b_allOrders;
    @FXML
    private ImageView i_main;
    @FXML
    private ImageView i_orderDonuts;
    @FXML
    private ImageView i_currentOrder;
    @FXML
    private ImageView i_allOrders;
    @FXML
    private ComboBox Coffee_ComboBox;
    @FXML
    private Button b_Decrement;
    @FXML
    private Button b_Increment;
    private int quantity;
    @FXML
    private Text t_Quantity;
    @FXML
    private Button b_AddToOrder;
    @FXML
    private Button b_RemoveFromOrder;
    @FXML
    private TextArea Coffee_OrderBasket_TextArea;
    @FXML
    private HBox ClearAll_HBox;
    @FXML
    private HBox areYouSure;
    @FXML
    private TextArea Coffee_OrderBasket_Subtotal;
    @FXML
    private CheckBox Check_0;
    @FXML
    private CheckBox Check_1;
    @FXML
    private CheckBox Check_2;
    @FXML
    private CheckBox Check_3;
    @FXML
    private CheckBox Check_4;
    private CheckBox[] checkBoxes;
    private CupSize[] Coffee_Sizes;
    private AddIn[] addInOptions =
            {AddIn.Sweet_Cream,AddIn.French_Vanilla,
            AddIn.Irish_Cream,AddIn.Caramel,AddIn.Mocha};
    private CupSize GetCoffeeSize(){
        switch(Coffee_ComboBox.getValue().toString()){
            case "Short":
                return CupSize.Short;
            case "Tall":
                return CupSize.Tall;
            case "Grande":
                return CupSize.Grande;
            case "Venti":
                return CupSize.Venti;
        }
        return null;
    }
    @FXML
    void OnDecrementPressed(){
        if(quantity == 0) return;
        quantity--;
        UpdateQuantityDisplay();
    }
    @FXML
    void OnIncrementPressed(){
        if(quantity == 5) return;
        quantity++;
        UpdateQuantityDisplay();
    }

    @FXML
    void OnAddToOrderPressed(){
        if(quantity == 0) return;
        Coffee coffeeToAdd = new Coffee(GetCoffeeSize(),quantity);
        for(int i = 0; i < MAX_COFFEE_ADD_INS; i++){
            if(checkBoxes[i].isSelected()) coffeeToAdd.addToAddIns(addInOptions[i]);
        }
        data.getCurrentOrder().addItem(coffeeToAdd);
        UpdateOrderBasketDisplay();
    }
    @FXML
    void OnRemoveFromOrderPressed(){
        if(quantity == 0) return;
        Coffee coffeeToRemove = new Coffee(GetCoffeeSize(),quantity);
        for(int i = 0; i < MAX_COFFEE_ADD_INS; i++){
            if(checkBoxes[i].isSelected()) coffeeToRemove.addToAddIns(addInOptions[i]);
        }
        if(data.getCurrentOrder().removeItem(coffeeToRemove)) UpdateOrderBasketDisplay();
    }
    @FXML
    void OnClearOrderPressed(){
        areYouSure.setVisible(true);
        ClearAll_HBox.setVisible(false);
    }
    @FXML
    public void OnConfirmClearPressed(){
        areYouSure.setVisible(false);
        ClearAll_HBox.setVisible(true);
        data.getCurrentOrder().clearAllItems();
        UpdateOrderBasketDisplay();
    }
    @FXML
    public void OnDenyClearPressed(){
        areYouSure.setVisible(false);
        ClearAll_HBox.setVisible(true);
    }
    @FXML
    void OnMainPressed(ActionEvent event) throws Exception {
        SceneSetter.setToScene(b_main,"main-view.fxml");
    }
    @FXML
    void OnOrderDonutsPressed(ActionEvent event) throws Exception {
        SceneSetter.setToScene(b_orderDonuts,"order-donuts-view.fxml");
    }
    @FXML
    void OnCurrentOrderPressed(ActionEvent event) throws Exception {
        SceneSetter.setToScene(b_currentOrder,"current-order-view.fxml");
    }
    @FXML
    void OnAllOrdersPressed(ActionEvent event) throws Exception {
        SceneSetter.setToScene(b_allOrders,"all-order-view.fxml");
    }
    public void UpdateOrderBasketDisplay(){
        Coffee_OrderBasket_TextArea.setText(data.getCurrentOrder().toString());
        Coffee_OrderBasket_Subtotal.setText("Subtotal: " + data.getCurrentOrder().MoneyFormat(data.getCurrentOrder().subTotal()));
    }
    public void UpdateQuantityDisplay(){
        t_Quantity.setText(quantity + "x");
    }
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        quantity = 0;
        UpdateQuantityDisplay();
        checkBoxes = new CheckBox[]{Check_0, Check_1, Check_2, Check_3, Check_4};
        Coffee_Sizes = new CupSize[]{CupSize.Short, CupSize.Tall, CupSize.Grande, CupSize.Venti};
        Coffee_ComboBox.getItems().setAll(Coffee_Sizes);
        Coffee_ComboBox.setValue(Coffee_Sizes[0]);
        UpdateOrderBasketDisplay();
    }
}
